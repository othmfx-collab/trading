/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum TradeStatus {
  WIN = 'WIN',
  LOSS = 'LOSS',
  RUNNING = 'RUNNING',
  BE = 'BE'
}

export enum Bias {
  BULLISH = 'BULLISH',
  BEARISH = 'BEARISH'
}

export enum Session {
  LONDON = 'London',
  NEW_YORK = 'New York',
  ASIA = 'Asia',
  LONDON_NY = 'London/NY'
}

export interface Trade {
  id: string;
  pair: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  poi: string;
  session: string;
  bias: Bias;
  pnlPercentage: number;
  pnlCash?: number;
  status: TradeStatus;
  chartUrl: string;
  chartImageUrl?: string;
  notes: string;
  createdAt: number;
  entryPrice?: number;
  size?: number;
  entryCondition?: string;
  exitCondition?: string;
  market?: string;
  instrumentType?: string;
  slPrice?: number;
  tpPrice?: number;
  strategyId?: string;
  mood?: string;
  commitmentScore?: number; // 1-5
}

export interface Strategy {
  id: string;
  name: string;
  image?: string;
  rules: string[];
}

export interface AppSettings {
  language: 'AR' | 'EN' | 'FR';
  theme: 'dark' | 'light';
  accountBalance: number;
  poiTypes: string[];
  sessions: string[];
  assets: {
    Stock: string[];
    Crypto: string[];
    Forex: string[];
    Commoditie: string[];
  };
  strategies: Strategy[];
}

export const DEFAULT_SETTINGS: AppSettings = {
  language: 'AR',
  theme: 'dark',
  accountBalance: 10000,
  poiTypes: ['OB', 'FVG', 'IFVG', 'QM', 'SNR', 'SBR', 'RBS', 'SMC', 'Order Block', 'Liquidity'],
  sessions: ['آسيا', 'لندن', 'نيويورك', 'لندن/نيويورك'],
  assets: {
    Stock: ['AAPL', 'MSFT', 'TSLA', 'NVDA'],
    Crypto: ['BTCUSD', 'ETHUSD', 'SOLUSD', 'BNBUSD'],
    Forex: ['EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD'],
    Commoditie: ['XAUUSD', 'XAGUSD', 'WTI']
  },
  strategies: []
};

export const TRANSLATIONS = {
  AR: {
    dashboard: 'الرزنامة',
    analytics: 'الإحصائيات',
    settings: 'الإعدادات',
    winners: 'الرابحة',
    losers: 'الخاسرة',
    winRate: 'نسبة الفوز',
    monthlyProfit: 'صافي الربح الشهري',
    addTrade: 'إضافة صفقة',
    poiPerformance: 'أداء نقاط الاهتمام (POI)',
    sessionPerformance: 'الأداء حسب الجلسة',
    dayPerformance: 'الأداء حسب أيام الأسبوع',
    language: 'اللغة',
    appearance: 'المظهر العام',
    dataManagement: 'إدارة البيانات',
    export: 'تصدير النسخة',
    import: 'استيراد النسخة',
    reset: 'تهيئة البرنامج بالكامل',
    saveSettings: 'حفظ الإعدادات',
    entryReasons: 'أسباب الدخول (AR)',
    sessionsTitle: 'أوقات الجلسات (AR)',
    today: 'اليوم',
    trades: 'صفقات',
    psychology: 'التحليل النفسي',
    mood: 'الحالة الذهنية',
    commitment: 'الالتزام بالخطة',
  },
  EN: {
    dashboard: 'Calendar',
    analytics: 'Analytics',
    settings: 'Settings',
    winners: 'Winners',
    losers: 'Losers',
    winRate: 'Win Rate',
    monthlyProfit: 'Monthly Net Profit',
    addTrade: 'Add Trade',
    poiPerformance: 'POI Performance',
    sessionPerformance: 'Session Performance',
    dayPerformance: 'Day Performance',
    language: 'Language',
    appearance: 'Appearance',
    dataManagement: 'Data Management',
    export: 'Export Data',
    import: 'Import Data',
    reset: 'Reset All Data',
    saveSettings: 'Save Settings',
    entryReasons: 'Entry Reasons',
    sessionsTitle: 'Sessions',
    today: 'Today',
    trades: 'Trades',
    psychology: 'Psychology Analysis',
    mood: 'Mental State',
    commitment: 'Plan Commitment',
  }
};
