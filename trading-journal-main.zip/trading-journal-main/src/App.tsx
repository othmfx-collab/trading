/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Minus,
  LayoutDashboard, 
  History, 
  Settings as SettingsIcon,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  X,
  Globe,
  Moon,
  Sun,
  Database,
  Trash2,
  FileDown,
  FileUp,
  Layout,
  Tag,
  Clock,
  Zap,
  Bell,
  BarChart2,
  CalendarDays,
  ImageIcon as ImageIcon,
  ExternalLink,
  User,
  LogOut,
  Award,
  Lightbulb,
  Bug,
  Edit3,
  Home as HomeIcon,
  Search,
  BookOpen,
  LineChart,
  History as HistoryIcon,
  Download,
  Share2,
  FileText,
  Mail,
  ShieldCheck,
  ShieldAlert,
  Smile,
  AlertCircle,
  Scale,
  RotateCcw,
  DollarSign,
  Monitor,
  Bitcoin,
  ArrowLeftRight,
  Archive,
  Hexagon,
  FolderKey,
  MinusCircle,
  Camera,
  Lock,
  ArrowRight,
  Eye,
  EyeOff,
  Mail as MailIcon,
  Check,
  Percent
} from 'lucide-react';
import { 
  AreaChart,
  Area,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ComposedChart,
  Bar,
  Cell
} from 'recharts';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut,
  User as FirebaseUser
} from 'firebase/auth';
import { auth, db, handleFirestoreError, OperationType } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { 
  Trade, 
  TradeStatus, 
  Bias, 
  TRANSLATIONS,
  AppSettings,
  DEFAULT_SETTINGS,
  Strategy
} from './types';
import { 
  DataService, 
  calculateWinRate, 
  calculateMonthlyProfit,
  getDailyStats,
  getPerformanceByDayOfWeek,
  getPerformanceBySession,
  getPerformanceByPOI,
  getAdvancedStats,
  getConsistencyScore,
  getWinLossBE,
  getMonthBestWorstDays,
  getPsychStats
} from './services';

// Helper for professional localization and currency
const UI_LOCALE = 'en-US';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Global financial formatter - Forces en-US Latin digits and clean $ symbol
const formatFinancial = (val: number, mode: 'percentage' | 'currency', balance: number) => {
  if (mode === 'currency') {
    const currencyVal = (val / 100) * balance;
    // Force en-US for Latin numbers, remove US from currency
    const formatted = new Intl.NumberFormat(UI_LOCALE, { 
      style: 'currency', 
      currency: 'USD', 
      maximumFractionDigits: 0 
    }).format(currencyVal).replace('US', '');
    
    const parts = formatted.split('$');
    return (
      <span className="font-mono flex items-baseline gap-0.5">
        <span className="text-[0.7em] opacity-70 font-sans leading-none">$</span>
        <span>{parts[1] || parts[0]}</span>
      </span>
    );
  }
  return (
    <span className="font-mono tracking-tighter">
      {val >= 0 ? '+' : ''}{val.toFixed(1)}%
    </span>
  );
};

// --- UI Components ---

const Card = ({ children, className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("bg-[var(--surface)] border border-[var(--border-color)] rounded-2xl p-4 shadow-sm dark:shadow-none", className)} {...props}>
    {children}
  </div>
);

const IconButton = ({ icon: Icon, onClick, active }: any) => (
  <button 
    onClick={onClick}
    className={cn(
      "p-2 rounded-xl border transition-all",
      active 
        ? "bg-[#635BFF22] border-[#635BFF] text-[#635BFF]" 
        : "bg-[var(--on-surface)] border-transparent text-gray-500"
    )}
  >
    <Icon size={20} />
  </button>
);

const TagItem = ({ label, onRemove }: any) => (
  <div className="bg-[var(--on-surface)] text-[var(--text-main)] px-3 py-1.5 rounded-lg flex items-center gap-2 text-xs border border-[var(--border-color)]">
    <span>{label}</span>
    <button onClick={onRemove} className="text-gray-500 hover:text-white">
      <X size={12} />
    </button>
  </div>
);

const StatCard = ({ label, value, subValue, type, icon: Icon }: any) => (
  <Card className={cn(
    "flex flex-col gap-1 relative overflow-hidden transition-all hover:shadow-md", 
    type === 'success' ? 'border-b-4 border-[#00C853]' : type === 'danger' ? 'border-b-4 border-[#D50000]' : 'border-b-4 border-[#635BFF]'
  )}>
    <div className="flex justify-between items-start">
      <span className={cn("text-[10px] font-black uppercase tracking-widest", type === 'success' ? 'text-[#00C853]' : type === 'danger' ? 'text-[#D50000]' : 'text-[#635BFF]')}>{label}</span>
      {Icon && <Icon size={14} className="text-[var(--text-muted)]" />}
    </div>
    <div className="flex items-baseline gap-2 mt-1">
      <span className="text-2xl font-black text-[var(--text-main)] italic tracking-tighter">{value}</span>
      <span className={cn("text-sm font-bold", type === 'success' ? 'text-[#00C853]' : type === 'danger' ? 'text-[#D50000]' : 'text-[var(--text-main)]')}>{subValue}</span>
    </div>
  </Card>
);

// --- Auth Screens ---

const WelcomeScreen = ({ onCreateAccount, onLogin }: any) => (
  <div className="flex flex-col h-screen bg-[var(--background)] text-[var(--text-main)] p-6 justify-between overflow-hidden">
    <div className="flex items-center gap-2 mt-4 opacity-80">
      <div className="w-8 h-8 rounded-lg bg-[#635BFF11] border border-[#635BFF22] flex items-center justify-center">
        <TrendingUp size={16} className="text-[#635BFF]" />
      </div>
      <span className="text-sm font-bold tracking-tight text-[var(--text-main)]">Trading Journal Book</span>
    </div>

    <div className="flex flex-col items-center gap-8 mb-20 animate-in fade-in slide-in-from-bottom-10 duration-1000">
      <div className="w-48 h-48 rounded-full bg-[#FFE169] flex items-center justify-center shadow-[0_0_100px_rgba(255,225,105,0.15)]">
        <div className="w-32 h-32 bg-white rounded-2xl shadow-xl flex items-center justify-center p-4 relative">
          <BookOpen size={64} className="text-[#333] opacity-20" />
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 gap-2">
            <div className="w-full h-2 bg-gray-100 rounded-full" />
            <div className="w-3/4 h-2 bg-gray-100 rounded-full" />
            <div className="w-1/2 h-2 bg-gray-100 rounded-full" />
            <div className="absolute top-4 right-4 text-[#FF4B4B] transform rotate-45">
              <Edit3 size={24} />
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center gap-3 text-center">
        <h1 className="text-4xl font-black italic uppercase tracking-tight leading-none text-[var(--text-main)]">
          Trading <br /> Journal Book
        </h1>
        <p className="text-[var(--text-muted)] font-medium opacity-60">Analyse trades in a better way</p>
      </div>
    </div>

    <div className="flex flex-col gap-4 mb-12 w-full animate-in fade-in slide-in-from-bottom-10 duration-1000 delay-200">
      <button 
        onClick={onCreateAccount}
        className="w-full bg-[#635BFF] py-5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-[0_20px_40px_rgba(99,91,255,0.2)] transition-transform active:scale-[0.98] text-white"
      >
        Create New Account
        <ArrowRight size={18} />
      </button>
      <button 
        onClick={onLogin}
        className="w-full bg-[var(--surface)] border border-[var(--border-color)] py-5 rounded-2xl font-black text-sm text-[var(--text-main)] transition-transform active:scale-[0.98] shadow-sm"
      >
        I already have an account
      </button>
    </div>

    <div className="flex justify-center flex-col items-center gap-1 opacity-40 mb-4">
      <p className="text-[10px] font-medium text-center max-w-[250px] text-[var(--text-muted)]">
        By using TradeLog, you agree to our <span className="font-black underline">Terms of Service</span> and <span className="font-black underline">Privacy Policy</span>.
      </p>
    </div>
  </div>
);

const AuthScreen = ({ mode, onBack, onSuccess, onToggleMode }: { mode: 'signup' | 'login', onBack: () => void, onSuccess: () => void, onToggleMode: () => void }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (mode === 'signup') {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    setLoading(true);
    setError('');
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Google Auth failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[var(--background)] text-[var(--text-main)] p-6 overflow-y-auto scrollbar-hide">
      <button onClick={onBack} className="mt-4 w-10 h-10 rounded-full bg-[var(--surface)] flex items-center justify-center self-start mb-12 border border-[var(--border-color)] text-[var(--text-main)] shadow-sm">
        <ChevronLeft size={20} />
      </button>

      <div className="flex flex-col gap-2 mb-10">
        <h1 className="text-4xl font-black italic uppercase tracking-tight text-[var(--text-main)]">
          {mode === 'signup' ? 'Create New Account' : 'Welcome Back'}
        </h1>
        <p className="text-[var(--text-muted)] font-medium opacity-60">
          {mode === 'signup' ? 'Start your trading journey today.' : 'Please sign in to your account.'}
        </p>
      </div>

      <form onSubmit={handleEmailAuth} className="flex flex-col gap-4">
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl text-red-500 text-xs font-bold mb-2">
            {error}
          </div>
        )}
        
        <div className="relative group">
          <input 
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email"
            required
            className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-2xl px-14 py-5 text-sm font-bold outline-none focus:border-[#635BFF] focus:bg-[var(--background)] transition-all text-[var(--text-main)] placeholder:text-[var(--text-muted)]/50"
          />
          <MailIcon size={20} className="absolute left-5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] group-focus-within:text-[#635BFF] transition-colors" />
        </div>

        <div className="relative group">
          <input 
            type={showPassword ? "text" : "password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            required
            className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-2xl px-14 py-5 text-sm font-bold outline-none focus:border-[#635BFF] focus:bg-[var(--background)] transition-all text-[var(--text-main)] placeholder:text-[var(--text-muted)]/50"
          />
          <Lock size={20} className="absolute left-5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] group-focus-within:text-[#635BFF] transition-colors" />
          <button 
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-5 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-[var(--text-main)]"
          >
            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
          </button>
        </div>

        <button 
          disabled={loading}
          type="submit"
          className="w-full bg-[#307BFF] py-5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 mt-4 shadow-lg shadow-[#307BFF33] transition-transform active:scale-[0.98] disabled:opacity-50 text-white"
        >
          {loading ? 'Processing...' : mode === 'signup' ? 'Create Account' : 'Sign In'}
        </button>
      </form>

      <div className="flex items-center gap-4 my-10">
        <div className="flex-1 h-px bg-[var(--border-color)]" />
        <span className="text-[10px] font-black text-[var(--text-muted)] uppercase tracking-widest">OR</span>
        <div className="flex-1 h-px bg-[var(--border-color)]" />
      </div>

      <button 
        onClick={handleGoogleAuth}
        className="w-full bg-[var(--surface)] border border-[var(--border-color)] py-5 rounded-2xl font-black text-xs text-[var(--text-main)] flex items-center justify-center gap-3 transition-transform active:scale-[0.98] shadow-sm"
      >
        <svg width="18" height="18" viewBox="0 0 24 24">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
          <path d="M5.84 14.1c-.22-.66-.35-1.36-.35-2.1s.13-1.44.35-2.1V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.84z" fill="#FBBC05"/>
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
        </svg>
        Continue with Google
      </button>

      <button
        type="button"
        onClick={onToggleMode}
        className="mt-8 text-sm font-bold text-[var(--text-muted)] hover:text-[var(--text-main)] transition-colors"
      >
        {mode === 'signup' ? (
          <>Already have an account? <span className="text-[#307BFF]">Log in</span></>
        ) : (
          <>Don't have an account? <span className="text-[#307BFF]">Create one</span></>
        )}
      </button>

      <div className="flex justify-center flex-col items-center gap-1 opacity-30 mt-auto pt-10">
        <p className="text-[10px] font-medium text-center text-[var(--text-muted)]">
          By continuing, you agree to our <span className="font-black underline">Terms of Service</span> & <span className="font-black underline">Privacy Policy</span>.
        </p>
      </div>
    </div>
  );
};

const ENTRY_CONDITIONS = [
  "Accurate Entry",
  "Early Entry",
  "Entry Without confirmation",
  "Late Entry",
  "Fomo Entry"
];

const EXIT_CONDITIONS = [
  "Target Hit",
  "SL Hit",
  "Trailing SL Hit",
  "Exited in fear",
  "Early Exit then Target Hit",
  "SL Hit then Target Hit",
  "Trailing SL Hit then Target Hit",
  "Trailing SL Hit then SL Hit"
];

const ImageModal = ({ url, onCancel }: { url: string, onCancel: () => void }) => (
  <div className="fixed inset-0 z-[300] flex items-center justify-center p-6">
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onCancel}
      className="absolute inset-0 bg-black/40 backdrop-blur-sm"
    />
    <motion.div 
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0.9, opacity: 0 }}
      className="relative w-full max-w-lg aspect-auto max-h-[80vh] rounded-3xl overflow-hidden shadow-2xl bg-[var(--background)] border border-[var(--border-color)]"
    >
      <img src={url} alt="Chart Analysis" className="w-full h-full object-contain" />
      <button 
        onClick={onCancel}
        className="absolute top-4 right-4 bg-black/60 p-2 rounded-full text-white hover:bg-black transition-colors shadow-lg"
      >
        <X size={20} />
      </button>
    </motion.div>
  </div>
);

const JournalView = ({ trades, t, settings, displayMode }: { trades: Trade[], t: any, settings: AppSettings, displayMode: 'percentage' | 'currency' }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [filter, setFilter] = useState({ pair: '', market: 'All' });

  const filteredTrades = trades.filter(trade => {
    const matchPair = filter.pair === '' || trade.pair.toLowerCase().includes(filter.pair.toLowerCase());
    const matchMarket = filter.market === 'All' || trade.market === filter.market;
    return matchPair && matchMarket;
  });

  const formatItemVal = (val: number) => formatFinancial(val, displayMode, settings.accountBalance);

  return (
    <div className="flex flex-col gap-4 px-1 pb-24 pt-12">
      <AnimatePresence>
        {selectedImage && (
          <ImageModal url={selectedImage} onCancel={() => setSelectedImage(null)} />
        )}
      </AnimatePresence>
      <div className="flex items-center justify-between mb-4 px-4">
        <h2 className="text-xl font-black text-[var(--text-main)] italic uppercase">History</h2>
        <span className="text-[10px] font-black text-[var(--text-muted)] uppercase bg-[var(--on-surface)] px-3 py-1 rounded-full border border-[var(--border-color)] shadow-sm">
          {filteredTrades.length} {t.trades}
        </span>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 mb-1 px-4">
        <div className="relative">
          <input 
            type="text"
            placeholder="Search pair..."
            value={filter.pair}
            onChange={(e) => setFilter({ ...filter, pair: e.target.value })}
            className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-xl px-10 py-2.5 text-xs outline-none focus:border-[#635BFF] font-black italic tracking-wide text-[var(--text-main)]"
          />
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500" />
        </div>
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
          {['All', 'Forex', 'Stock', 'Crypto', 'Commoditie'].map(m => (
            <button
              key={m}
              onClick={() => setFilter({ ...filter, market: m })}
              className={cn(
                "px-4 py-1.5 rounded-full text-[9px] font-black uppercase border transition-all whitespace-nowrap",
                filter.market === m 
                  ? "bg-[#635BFF] border-[#635BFF] text-white shadow-sm shadow-[#635BFF44]" 
                  : "bg-[var(--surface)] border-[var(--border-color)] text-[var(--text-muted)] hover:text-[var(--text-main)]"
              )}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      {filteredTrades.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center py-20 text-center opacity-50">
          <BookOpen size={40} className="mb-4 text-[#635BFF]" />
          <h2 className="text-base font-black italic uppercase text-[var(--text-main)] border-none">No trades yet</h2>
          <p className="text-[10px] font-bold uppercase tracking-widest text-[var(--text-muted)]">Start journaling your trades</p>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {filteredTrades.slice().sort((a, b) => b.createdAt - a.createdAt).map(trade => (
            <Card key={trade.id} className="flex items-center justify-between gap-4 p-4 border border-[var(--border-color)] bg-[var(--surface)] hover:border-[#635BFF22] transition-colors rounded-xl shadow-sm dark:shadow-none">
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-black text-[var(--text-main)] italic uppercase tracking-tight">{trade.pair}</span>
                  <div className={cn(
                    "w-1.5 h-1.5 rounded-full",
                    trade.bias === Bias.BULLISH ? "bg-[#00C853]" : "bg-[#FF1744]"
                  )} />
                  <span className={cn(
                    "text-[8px] px-1.5 py-0.5 rounded-md font-black uppercase tracking-widest leading-none",
                    trade.bias === Bias.BULLISH ? "bg-[#00C85311] text-[#00C853]" : "bg-[#FF174411] text-[#FF1744]"
                  )}>
                    {trade.bias === Bias.BULLISH ? 'Bullish' : 'Bearish'}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-tight opacity-70">
                  <div className="flex items-center gap-1">
                    <CalendarDays size={10} />
                    <span>{trade.date}</span>
                  </div>
                  <span className="w-1 h-1 bg-[var(--text-muted)] opacity-30 rounded-full" />
                  <div className="flex items-center gap-1">
                    <Zap size={10} />
                    <span>{trade.poi}</span>
                  </div>
                  <span className="w-1 h-1 bg-[var(--text-muted)] opacity-30 rounded-full" />
                  <div className="flex items-center gap-1">
                    <Clock size={10} />
                    <span>{trade.session}</span>
                  </div>
                  {(trade.chartUrl || trade.chartImageUrl) && (
                    <>
                      <span className="w-1 h-1 bg-[var(--text-muted)] opacity-30 rounded-full" />
                      <div className="flex items-center gap-2">
                        {trade.chartUrl && (
                          <a href={trade.chartUrl} target="_blank" rel="noopener noreferrer" className="p-1 hover:bg-[#635BFF11] rounded transition-colors text-[#635BFF]">
                            <ExternalLink size={10} />
                          </a>
                        )}
                        {trade.chartImageUrl && (
                           <button onClick={() => setSelectedImage(trade.chartImageUrl!)} className="p-1 hover:bg-[#635BFF11] rounded transition-colors text-[#635BFF]">
                             <ImageIcon size={10} />
                           </button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              </div>
              <div className="flex flex-col items-end gap-0.5">
                <span className={cn(
                  "text-lg font-black tracking-tighter",
                  trade.status === TradeStatus.WIN ? "text-[#00C853]" : trade.status === TradeStatus.LOSS ? "text-[#FF1744]" : trade.status === TradeStatus.BE ? "text-yellow-500" : "text-[#635BFF]"
                )}>
                  {formatItemVal(trade.pnlPercentage)}
                </span>
                <div className="flex items-center gap-1.5">
                  <span className={cn(
                    "text-[7px] font-black uppercase tracking-[0.15em] px-1.5 py-0.5 rounded border leading-none",
                    trade.status === TradeStatus.WIN ? "bg-[#00C85311] text-[#00C853] border-[#00C85322]" : 
                    trade.status === TradeStatus.LOSS ? "bg-[#FF174411] text-[#FF1744] border-[#FF174422]" : 
                    trade.status === TradeStatus.BE ? "bg-yellow-500/10 text-yellow-500 border-yellow-500/20" : 
                    "bg-[#635BFF11] text-[#635BFF] border-[#635BFF22]"
                  )}>
                    {trade.status === TradeStatus.BE ? "B.E" : trade.status}
                  </span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

// --- Performance Dashboard Components ---

const PerformanceChart = ({ trades, timeframe }: { trades: Trade[], timeframe: 'Daily' | 'Weekly' | 'Monthly' | 'All Time' }) => {
  const chartData = useMemo(() => {
    if (trades.length === 0) return [];
    
    // Get stats by day
    const stats = getDailyStats(trades);
    const sortedDates = Object.keys(stats).sort();
    
    let cumulativePnl = 0;
    return sortedDates.map(date => {
      cumulativePnl += stats[date].pnl;
      return {
        name: new Date(date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
        daily: stats[date].pnl,
        equity: cumulativePnl,
        fullDate: date
      };
    });
  }, [trades]);

  const totalPnl = chartData.length > 0 ? chartData[chartData.length - 1].equity : 0;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col bg-[var(--surface)] rounded-[32px] p-6 border border-[var(--border-color)] shadow-2xl dark:shadow-none overflow-hidden relative">
        {/* Background Accent */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#635BFF] opacity-10 blur-[80px] -mr-16 -mt-16" />
        
        <div className="flex items-center justify-between mb-10 relative z-10">
           <div className="flex flex-col">
              <span className="text-[9px] font-black text-[var(--text-muted)] uppercase tracking-[0.4em] mb-1">Growth Curve</span>
              <h3 className="text-xl font-black italic uppercase tracking-tighter text-[var(--text-main)] leading-none">Equity Curve</h3>
           </div>
           <div className="flex flex-col items-end">
              <div className={cn(
                "text-2xl font-black italic tracking-tighter",
                totalPnl >= 0 ? "text-[#00E676]" : "text-[#FF5252]"
              )}>
                {totalPnl >= 0 ? '+' : ''}{totalPnl.toFixed(2)}%
              </div>
              <span className="text-[8px] font-black text-[var(--text-muted)] uppercase tracking-widest">Total P&L</span>
           </div>
        </div>

        <div className="h-[240px] w-full relative z-10">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 0, left: -25, bottom: 0 }}>
              <defs>
                <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#635BFF" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="#635BFF" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <Tooltip 
                cursor={{ stroke: 'rgba(99, 91, 255, 0.2)', strokeWidth: 1 }}
                contentStyle={{ 
                  backgroundColor: 'var(--background)', 
                  border: '1px solid var(--border-color)', 
                  borderRadius: '16px', 
                  fontSize: '10px', 
                  fontWeight: '900',
                  boxShadow: '0 10px 40px rgba(0,0,0,0.1)',
                  padding: '12px',
                  color: 'var(--text-main)'
                }}
                itemStyle={{ color: 'var(--text-main)' }}
              />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 8, fill: 'var(--text-muted)', fontWeight: '900' }}
                minTickGap={40}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 8, fill: 'var(--text-muted)', fontWeight: '900' }}
                tickFormatter={(val) => `${val}%`}
              />
              <Area 
                type="monotone" 
                dataKey="equity" 
                stroke="#635BFF" 
                strokeWidth={4}
                fillOpacity={1} 
                fill="url(#equityGradient)" 
                animationDuration={2000}
                dot={false}
                activeDot={{ r: 6, fill: '#635BFF', stroke: '#fff', strokeWidth: 2 }}
              />
              <Bar 
                dataKey="daily" 
                radius={[4, 4, 0, 0]} 
                opacity={0.1}
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.daily >= 0 ? '#00E676' : '#FF5252'} />
                ))}
              </Bar>
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

const CalendarView = ({ trades, t, date, setDate, settings, displayMode, setDisplayMode }: { trades: Trade[], t: any, date: Date, setDate: (d: Date) => void, settings: AppSettings, displayMode: 'percentage' | 'currency', setDisplayMode: (m: 'percentage' | 'currency') => void }) => {
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  
  const daysInMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  const dailyStats = useMemo(() => getDailyStats(trades), [trades]);

  const isAr = settings.language === 'AR';
  const monthNamesEn = ["JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"];
  const monthNamesAr = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  const weekdaysEn = ["MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY", "SUNDAY"];
  const weekdaysAr = ["الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"];

  const nextMonth = () => {
    setDate(new Date(date.getFullYear(), date.getMonth() + 1, 1));
    setSelectedDay(null);
  };
  const prevMonth = () => {
    setDate(new Date(date.getFullYear(), date.getMonth() - 1, 1));
    setSelectedDay(null);
  };

  const monthLabel = isAr ? monthNamesAr[date.getMonth()] : monthNamesEn[date.getMonth()];
  const headDays = isAr ? weekdaysAr : weekdaysEn;

  // Helper to format currency/percent
  const formatVal = (val: number) => formatFinancial(val, displayMode, settings.accountBalance);

  const formatDateLabel = (dateStr: string) => {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    const day = d.getDate();
    const weekday = d.toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { weekday: 'short' });
    
    // Force Latin digits for date labels even in AR
    return `(${weekday} ${day})`;
  };

  // Monthly metrics
  const monthlyData = useMemo(() => {
    const start = new Date(date.getFullYear(), date.getMonth(), 1).getTime();
    const end = new Date(date.getFullYear(), date.getMonth() + 1, 0, 23, 59, 59).getTime();
    const monthTrades = trades.filter(t => t.createdAt >= start && t.createdAt <= end);
    const profitPercent = monthTrades.reduce((sum, t) => sum + t.pnlPercentage, 0);
    const winRate = calculateWinRate(monthTrades);
    const bw = getMonthBestWorstDays(trades, date);
    const wl = getWinLossBE(monthTrades);
    return { profitPercent, winRate, best: bw.best, bestDate: bw.bestDate, worst: bw.worst, worstDate: bw.worstDate, wl };
  }, [trades, date]);

  const maxDailyPnl = useMemo(() => {
    const values = Object.values(dailyStats).map((s: any) => Math.abs(s.pnl));
    return values.length > 0 ? Math.max(...values, 5) : 5;
  }, [dailyStats]);

  const getHeatmapClass = (pnl: number, theme: 'light' | 'dark' = 'dark') => {
    if (pnl === 0) {
      return theme === 'dark' 
        ? "bg-[#0A0A0A] text-gray-500 border-white/[0.03]" 
        : "bg-[var(--surface)] text-[var(--text-muted)] border-[var(--border-color)]";
    }
    const intensity = Math.abs(pnl) / maxDailyPnl;
    const isDark = theme === 'dark';
    
    if (pnl > 0) {
      if (intensity < 0.2) return isDark ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-emerald-50 text-emerald-600 border-emerald-100";
      if (intensity < 0.45) return isDark ? "bg-emerald-500/30 text-emerald-300 border-emerald-500/40" : "bg-emerald-100 text-emerald-700 border-emerald-200";
      if (intensity < 0.75) return isDark ? "bg-emerald-400 text-black border-emerald-500/50" : "bg-emerald-300 text-emerald-900 border-emerald-400/30"; 
      return isDark 
        ? "bg-[#00C853] text-black border-white/30 font-black shadow-[0_0_25px_rgba(0,200,83,0.15)]"
        : "bg-[#00C853] text-white border-none font-black shadow-lg shadow-emerald-200/50";
    } else {
      if (intensity < 0.2) return isDark ? "bg-rose-500/10 text-rose-400 border-rose-500/20" : "bg-rose-50 text-rose-600 border-rose-100";
      if (intensity < 0.45) return isDark ? "bg-rose-500/30 text-rose-300 border-rose-500/40" : "bg-rose-100 text-rose-700 border-rose-200";
      if (intensity < 0.75) return isDark ? "bg-rose-400 text-black border-rose-500/50" : "bg-rose-300 text-rose-900 border-rose-400/30";
      return isDark
        ? "bg-[#D50000] text-white border-white/30 font-black shadow-[0_0_25px_rgba(213,0,0,0.15)]"
        : "bg-[#D50000] text-white border-none font-black shadow-lg shadow-rose-200/50";
    }
  };

  const tradesOnSelectedDay = selectedDay ? trades.filter(t => t.date === selectedDay) : [];

  return (
    <div className="flex flex-col gap-3 w-full px-0">
      {/* 1. Dashboard Header (Stats Bar) - High Performance Minimal Rows */}
      <div className="flex flex-col gap-1.5 px-3 px-safe">
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-[var(--surface)] p-3 rounded-xl border border-[var(--border-color)] flex items-center justify-between shadow-sm">
            <div className="flex flex-col gap-0.5">
              <span className="text-[7px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">TOTAL P&L</span>
              <div className={cn("text-xl font-black italic tracking-tighter truncate leading-none font-mono", monthlyData.profitPercent >= 0 ? "text-[#00C853]" : "text-[#D50000]")}>
                {formatVal(monthlyData.profitPercent)}
              </div>
            </div>
            <TrendingUp size={14} className={cn(monthlyData.profitPercent >= 0 ? "text-[#00C853]" : "text-[#D50000] rotate-180 opacity-40")} />
          </div>
          <div className="bg-[var(--surface)] p-3 rounded-xl border border-[var(--border-color)] flex flex-col gap-0.5 shadow-sm">
            <span className="text-[7px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">WIN RATE</span>
            <span className="text-xl font-black italic tracking-tighter text-[#635BFF] font-mono leading-none">
              {monthlyData.winRate.toFixed(0)}%
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="bg-[var(--surface)] p-3 rounded-xl border border-[var(--border-color)] flex items-center justify-between shadow-sm">
            <div className="flex flex-col gap-0.5">
               <span className="text-[7px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">BEST DAY</span>
               <div className="flex items-baseline gap-1.5">
                 <span className="text-base font-black italic tracking-tighter text-[#00C853] leading-none font-mono">
                   {formatVal(monthlyData.best)}
                 </span>
                 <span className="text-[6px] font-bold text-gray-400 tracking-tight leading-none uppercase truncate mb-0.5">
                   {formatDateLabel(monthlyData.bestDate)}
                 </span>
               </div>
            </div>
          </div>
          <div className="bg-[var(--surface)] p-3 rounded-xl border border-[var(--border-color)] flex items-center justify-between shadow-sm">
            <div className="flex flex-col gap-0.5">
               <span className="text-[7px] font-black text-gray-500 uppercase tracking-widest leading-none mb-1">LOWEST DAY</span>
               <div className="flex items-baseline gap-1.5">
                 <span className="text-base font-black italic tracking-tighter text-[#D50000] leading-none font-mono">
                   {formatVal(monthlyData.worst)}
                 </span>
                 <span className="text-[6px] font-bold text-gray-400 tracking-tight leading-none uppercase truncate mb-0.5">
                   {formatDateLabel(monthlyData.worstDate)}
                 </span>
               </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-[var(--background)] rounded-none p-0 relative w-full mt-2 border-y border-[var(--border-color)]">
        <div className="flex items-center justify-between px-4 py-8">
          <div className="flex flex-col gap-1.5">
             <h3 className="text-3xl font-black uppercase text-[var(--text-main)] italic leading-none tracking-tighter">
               {monthLabel} {date.getFullYear()}
             </h3>
             <div className="h-1 w-16 bg-[#635BFF] rounded-full shadow-[0_0_10px_#635BFF44]" />
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-0.5 bg-[var(--surface)] rounded-lg p-0.5 border border-[var(--border-color)]">
               <button onClick={prevMonth} className="p-2 hover:bg-black/5 rounded-md transition-colors text-gray-500 hover:text-[var(--text-main)]"><ChevronLeft size={20} /></button>
               <button onClick={nextMonth} className="p-2 hover:bg-black/5 rounded-md transition-colors text-gray-500 hover:text-[var(--text-main)]"><ChevronRight size={20} /></button>
            </div>

            <div className="flex bg-[var(--surface)] rounded-lg p-0.5 border border-[var(--border-color)]">
               <button 
                onClick={() => setDisplayMode('currency')}
                className={cn(
                  "px-4 py-2 text-[10px] font-black rounded-md transition-all uppercase leading-none", 
                  displayMode === 'currency' ? "bg-[#635BFF] text-white shadow-sm" : "text-[var(--text-muted)]"
                )}
               >
                 $
               </button>
               <button 
                onClick={() => setDisplayMode('percentage')}
                className={cn(
                  "px-4 py-2 text-[10px] font-black rounded-md transition-all uppercase leading-none", 
                  displayMode === 'percentage' ? "bg-[#635BFF] text-white shadow-sm" : "text-[var(--text-muted)]"
                )}
               >
                 %
               </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-px text-center mb-0 px-0 bg-[var(--border-color)] border-b border-[var(--border-color)]">
          {headDays.map(d => (
            <span key={d} className="text-[9px] sm:text-[10px] text-[var(--text-main)] font-black py-4 tracking-tight uppercase leading-none bg-[var(--surface)]">
              {d}
            </span>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-px rounded-none overflow-hidden bg-[var(--border-color)] border-b border-[var(--border-color)]">
          {Array.from({ length: (firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1) }).map((_, i) => (
            <div key={`empty-${i}`} className="bg-[var(--surface)] aspect-square opacity-40" />
          ))}
          
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1;
            const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const stats = dailyStats[dateStr];
            const isSelected = selectedDay === dateStr;

            return (
              <button 
                key={day} 
                onClick={() => setSelectedDay(isSelected ? null : dateStr)}
                className={cn(
                  "relative aspect-square outline-none group hover:z-10",
                  settings.theme === 'dark' ? "bg-black" : "bg-[var(--surface)]"
                )}
              >
                <div className={cn(
                  "absolute inset-0 flex flex-col items-center justify-between py-2 transition-all overflow-hidden",
                  getHeatmapClass(stats?.pnl || 0, settings.theme)
                )}>
                  <span className={cn(
                    "w-full text-left px-2 text-[11px] sm:text-[12px] font-bold opacity-60 leading-none",
                    settings.theme === 'light' && "text-black opacity-40"
                  )}>
                    {day}
                  </span>

                  {stats ? (
                    <div className="flex flex-col items-center justify-center flex-1 w-full -mt-2 group-hover:scale-105 transition-transform">
                      <div className={cn(
                        "text-[12px] sm:text-[14px] font-black leading-none font-mono tracking-tighter drop-shadow-md",
                        settings.theme === 'light' && "text-gray-900 drop-shadow-none"
                      )}>
                        {formatVal(stats.pnl)}
                      </div>
                      <div className={cn(
                        "text-[7px] font-black opacity-60 uppercase leading-none tracking-tighter mt-1 px-1 rounded-sm",
                        settings.theme === 'light' ? "bg-black/5 text-black" : "bg-black/5 text-white"
                      )}>
                         {stats.wins + stats.losses} Tr
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1" />
                  )}

                  {stats && (
                    <div className="w-full flex justify-center pb-1">
                       <div className={cn(
                        "flex h-1.5 w-[70%] rounded-full overflow-hidden border border-white/5",
                        settings.theme === 'light' ? "bg-gray-200" : "bg-black/5"
                       )}>
                          <div className="bg-[#00C853] h-full" style={{ width: `${(stats.wins / (stats.wins + stats.losses)) * 100}%` }} />
                          <div className="bg-[#D50000] h-full border-l border-black/10" style={{ width: `${(stats.losses / (stats.wins + stats.losses)) * 100}%` }} />
                       </div>
                    </div>
                  )}

                  {isSelected && (
                    <motion.div 
                      layoutId="cal-select"
                      className="absolute inset-0 border-2 border-[#635BFF] z-20 shadow-[0_0_15px_#635BFF44]"
                    />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Global Total Row - Slim Bar */}
        <div className={cn("flex items-center justify-between gap-4 text-[9px] font-black uppercase tracking-widest p-6", settings.theme === 'dark' ? "bg-[#050505] text-gray-500" : "bg-gray-50 text-gray-600 border-t border-gray-100")}>
           <div className="flex items-center gap-2 font-mono">
              <span className="opacity-50">MONTH RESULTS:</span>
              <span className={cn("px-2.5 py-1 rounded-md border", settings.theme === 'dark' ? "text-white bg-white/5 border-white/5" : "text-gray-900 bg-white border-gray-200")}>{monthlyData.wl.total} TRADES</span>
           </div>
           <div className="flex items-center gap-4 font-mono">
              <div className="flex items-center gap-1.5">
                 <div className="w-2 h-2 rounded-full bg-[#00C853] shadow-[0_0_10px_#00C85344]" />
                 <span className="text-[#00C853]">{monthlyData.wl.win}W</span>
              </div>
              <div className="flex items-center gap-1.5">
                 <div className="w-2 h-2 rounded-full bg-[#D50000] shadow-[0_0_10px_#D5000044]" />
                 <span className="text-[#D50000]">{monthlyData.wl.loss}L</span>
              </div>
           </div>
        </div>
      </div>

      {/* Daily Detail Modal */}
      <AnimatePresence>
        {selectedDay && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 sm:p-12">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedDay(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-lg bg-[var(--background)] border border-[var(--border-color)] rounded-[32px] overflow-hidden shadow-2xl flex flex-col max-h-[80vh]"
            >
              {/* Header */}
              <div className="p-6 border-b border-[var(--border-color)] bg-gradient-to-b from-[var(--on-surface)] to-transparent">
                <div className="flex items-center justify-between mb-4">
                   <div className="flex flex-col">
                      <span className="text-[10px] font-black text-[#635BFF] uppercase tracking-[0.2em]">{selectedDay}</span>
                      <h2 className="text-2xl font-black italic uppercase italic text-[var(--text-main)]">Daily Summary</h2>
                   </div>
                   <button onClick={() => setSelectedDay(null)} className="p-2 bg-[var(--on-surface)] rounded-full hover:bg-[var(--surface)] transition-colors border border-[var(--border-color)] text-[var(--text-muted)]">
                      <X size={20} />
                   </button>
                </div>

                {dailyStats[selectedDay] && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col p-4 bg-[var(--surface)] rounded-2xl border border-[var(--border-color)]">
                       <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase mb-1">{isAr ? 'الأداء اليومي' : 'Daily P&L'}</span>
                       <span className={cn(
                         "text-2xl font-black italic font-mono",
                         dailyStats[selectedDay].pnl >= 0 ? "text-[#00E676]" : "text-[#FF5252]"
                       )}>
                         {formatFinancial(dailyStats[selectedDay].pnl, displayMode, settings.accountBalance)}
                       </span>
                    </div>
                    <div className="flex flex-col p-4 bg-[var(--surface)] rounded-2xl border border-[var(--border-color)]">
                       <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase mb-1">{isAr ? 'الصفقات (W/L)' : 'Trades (W/L)'}</span>
                       <div className="flex items-baseline gap-2">
                          <span className="text-2xl font-black italic text-[var(--text-main)]">{tradesOnSelectedDay.length}</span>
                          <span className="text-sm font-bold text-[var(--text-muted)] italic">
                             (<span className="text-[#00E676]">{dailyStats[selectedDay].wins}</span>/<span className="text-[#FF5252]">{dailyStats[selectedDay].losses}</span>)
                          </span>
                       </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Trade List */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide">
                {tradesOnSelectedDay.length === 0 ? (
                  <div className="py-12 flex flex-col items-center justify-center opacity-40 text-center gap-3">
                     <BookOpen size={48} className="text-[#635BFF]" />
                     <span className="text-sm font-bold text-[var(--text-main)]">No active trades recorded this day</span>
                  </div>
                ) : (
                  tradesOnSelectedDay.map(trade => (
                    <Card key={trade.id} className="flex flex-col gap-4 p-5 bg-[var(--surface)] border border-[var(--border-color)] hover:border-[#635BFF33] transition-all group overflow-hidden relative shadow-sm">
                      {/* Status Strip */}
                      <div className={cn(
                        "absolute left-0 top-0 bottom-0 w-1",
                        trade.status === TradeStatus.WIN ? "bg-[#00E676]" : trade.status === TradeStatus.LOSS ? "bg-[#FF5252]" : "bg-gray-500"
                      )} />
                      
                      <div className="flex items-center justify-between">
                        <div className="flex flex-col">
                           <div className="flex items-center gap-2">
                              <span className="text-lg font-black italic uppercase tracking-tight text-[var(--text-main)]">{trade.pair}</span>
                              <span className={cn(
                                "text-[8px] font-bold px-2 py-0.5 rounded uppercase tracking-widest",
                                trade.bias === Bias.BULLISH ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                              )}>
                                {trade.bias}
                              </span>
                           </div>
                           <span className="text-[9px] text-[var(--text-muted)] font-bold uppercase tracking-tight opacity-70">
                              {trade.session} SESSION • {trade.poi}
                           </span>
                        </div>
                        <div className="flex flex-col items-end">
                           <span className={cn(
                             "text-lg font-black italic",
                             trade.pnlPercentage >= 0 ? "text-[#00C853]" : "text-[#FF5252]"
                           )}>
                             {trade.pnlPercentage >= 0 ? '+' : ''}{trade.pnlPercentage.toFixed(1)}%
                           </span>
                           <span className="text-[8px] font-black uppercase tracking-widest opacity-40 text-[var(--text-muted)]">{trade.status}</span>
                        </div>
                      </div>

                      {trade.notes && (
                        <div className="bg-[var(--on-surface)] p-3 rounded-xl border border-[var(--border-color)]">
                           <p className="text-[10px] text-[var(--text-muted)] font-medium leading-relaxed line-clamp-2">"{trade.notes}"</p>
                        </div>
                      )}
                    </Card>
                  ))
                )}
              </div>

              {/* Actions */}
              <div className="p-6 bg-[var(--surface)] border-t border-[var(--border-color)]">
                <button 
                  onClick={() => setSelectedDay(null)}
                  className="w-full bg-[#635BFF] py-4 rounded-2xl font-black italic uppercase text-xs shadow-xl shadow-[#635BFF33] transition-all active:scale-95 text-white"
                >
                  Close Summary
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

const SectionHeader = ({ label }: { label: string }) => (
  <div className="flex items-center gap-3">
    <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--border-color)] to-transparent" />
    <span className="text-[10px] font-black text-gray-500 uppercase tracking-[0.3em]">{label}</span>
    <div className="h-px flex-1 bg-gradient-to-r from-transparent via-[var(--border-color)] to-transparent" />
  </div>
);

const AnalyticsView = ({ trades, settings, t, displayMode }: { trades: Trade[], settings: AppSettings, t: any, displayMode: 'percentage' | 'currency' }) => {
  const isAr = settings.language === 'AR';
  const poiData = useMemo(() => getPerformanceByPOI(trades, settings.poiTypes), [trades, settings.poiTypes]);
  const sessionData = useMemo(() => getPerformanceBySession(trades, settings.sessions), [trades, settings.sessions]);
  const dayData = useMemo(() => getPerformanceByDayOfWeek(trades), [trades]);
  const advanced = useMemo(() => getAdvancedStats(trades), [trades]);
  const consistencyScore = useMemo(() => getConsistencyScore(trades), [trades]);
  const psych = useMemo(() => getPsychStats(trades), [trades]);
  const [timeframe, setTimeframe] = useState<'Daily' | 'Weekly' | 'Monthly' | 'All Time'>('Daily');

  const stats = useMemo(() => {
     const winRate = calculateWinRate(trades);
     const wl = getWinLossBE(trades);
     const adv = getAdvancedStats(trades);
     return { winRate, wl, adv };
  }, [trades]);

  const moodMap: Record<string, string> = {
    calm: isAr ? '😌 هادئ' : '😌 Calm',
    anxious: isAr ? '😰 قلق' : '😰 Anxious',
    greedy: isAr ? '🤑 طماع' : '🤑 Greedy',
    angry: isAr ? '😤 غاضب' : '😤 Angry',
    neutral: isAr ? '😐 محايد' : '😐 Neutral'
  };

  const formatVal = (val: number) => formatFinancial(val, displayMode, settings.accountBalance);

  const PerformanceCard = ({ title, icon: Icon, data, defaultExpanded = false }: any) => {
    const [isExpanded, setIsExpanded] = useState(defaultExpanded);

    return (
      <div className="flex flex-col gap-2">
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center justify-between w-full p-4 bg-[var(--surface)] border border-[var(--border-color)] rounded-xl outline-none shadow-sm dark:shadow-none"
        >
          <div className="flex items-center gap-3">
            <div className="bg-[#635BFF11] p-1.5 rounded-lg border border-[#635BFF33]">
              {Icon && <Icon size={16} className="text-[#635BFF]" />}
            </div>
            <h3 className="text-sm font-black italic uppercase tracking-widest leading-none text-[var(--text-main)]">{title}</h3>
          </div>
          <motion.div
            animate={{ rotate: isExpanded ? 0 : -90 }}
            transition={{ duration: 0.2 }}
            className="text-[var(--text-muted)]"
          >
            <ChevronDown size={16} />
          </motion.div>
        </button>

        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="flex flex-col gap-1.5 pb-2">
                {data.map((item: any) => (
                  <div key={item.name} className="bg-[var(--surface)] rounded-lg p-3 flex items-center justify-between border border-[var(--border-color)]">
                    <div className="flex flex-col">
                      <span className="font-black text-xs text-[var(--text-main)] italic leading-none">{item.name}</span>
                      <span className="text-[8px] text-[var(--text-muted)] uppercase font-black tracking-widest mt-1 opacity-60">{item.count} TRADES</span>
                    </div>
                    <div className={cn("text-base font-black tracking-tighter font-mono", item.pnl >= 0 ? "text-[#00C853]" : "text-[#FF1744]")}>
                      {formatVal(item.pnl)}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-6 px-1 pb-32 pt-12 w-full">
      <div className="flex items-center justify-between px-4">
         <h1 className="text-2xl font-black italic uppercase italic tracking-tight underline decoration-[#635BFF] decoration-4 underline-offset-8 leading-none">Analytics</h1>
         <div className="bg-[var(--surface)] p-2.5 rounded-xl border border-[var(--border-color)] flex flex-col items-center min-w-[70px] shadow-sm">
            <span className="text-xs font-black text-[#635BFF] font-mono leading-none">{stats.winRate.toFixed(0)}%</span>
            <span className="text-[7px] font-black text-[var(--text-muted)] uppercase mt-1">Win Rate</span>
         </div>
      </div>

      <div className="px-1">
        <PerformanceChart trades={trades} timeframe={timeframe} />
      </div>

      <div className="grid grid-cols-2 gap-2">
         <div className="flex flex-col gap-1.5 bg-[var(--surface)] rounded-xl p-4 border border-[var(--border-color)] shadow-sm">
            <span className="text-[8px] font-black text-[var(--text-muted)] uppercase tracking-widest leading-none">Discipline</span>
            <div className="flex items-baseline gap-1 mt-1">
               <span className="text-2xl font-black italic text-[var(--text-main)] leading-none font-mono">{consistencyScore.toFixed(0)}</span>
               <span className="text-[8px] font-black text-[#635BFF] uppercase">Pts</span>
            </div>
            <div className="w-full h-1 bg-[var(--on-surface)] rounded-full overflow-hidden mt-2">
               <div className="h-full bg-[#635BFF]" style={{ width: `${consistencyScore}%` }} />
            </div>
         </div>
         <div className="flex flex-col gap-1.5 bg-[var(--surface)] rounded-xl p-4 border border-[var(--border-color)] shadow-sm">
            <span className="text-[8px] font-black text-[var(--text-muted)] uppercase tracking-widest leading-none">Performance</span>
            <div className="flex flex-col mt-1">
               <span className="text-2xl font-black italic text-[#00E676] leading-none font-mono">+{trades.filter(t => t.status === TradeStatus.WIN).length}</span>
               <span className="text-[8px] font-black text-[var(--text-muted)] uppercase tracking-widest mt-1 opacity-60">Wins Captured</span>
            </div>
         </div>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="flex flex-col gap-1 bg-[var(--surface)] rounded-xl p-4 border border-[var(--border-color)]">
           <span className="text-[8px] font-black text-[var(--text-muted)] uppercase leading-none">Avg Win / Loss</span>
           <div className="flex flex-col mt-2">
              <span className="text-lg font-black text-[#00E676] font-mono leading-none">+{advanced.avgWin.toFixed(1)}%</span>
              <span className="text-sm font-black text-[#FF5252] font-mono mt-0.5">-{advanced.avgLoss.toFixed(1)}%</span>
           </div>
        </div>
        <div className="flex flex-col gap-1 bg-[var(--surface)] rounded-xl p-4 border border-[var(--border-color)]">
           <span className="text-[8px] font-black text-[var(--text-muted)] uppercase leading-none">R:R Ratio</span>
           <div className="mt-2 text-right">
              <span className="text-2xl font-black italic tracking-tighter font-mono leading-none text-[var(--text-main)]">1:{advanced.rrRatio.toFixed(2)}</span>
           </div>
           <p className="text-[7px] text-[var(--text-muted)] font-black uppercase tracking-widest text-right mt-1 opacity-60">Realized</p>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <SectionHeader label="Distribution" />
        <PerformanceCard title={t.dayPerformance} icon={CalendarDays} data={dayData} />
        <PerformanceCard title={t.poiPerformance} icon={Zap} data={poiData} />
        <PerformanceCard title={t.sessionPerformance} icon={Clock} data={sessionData} />
        <PerformanceCard 
          title={t.psychology} 
          icon={Award} 
          data={psych.moods.map(m => ({
            name: moodMap[m.name] || m.name,
            count: m.count,
            pnl: m.pnl
          }))} 
        />
        <div className="flex flex-col gap-1 bg-[var(--surface)] rounded-xl p-6 shadow-sm relative overflow-hidden border border-[var(--border-color)]">
           <div className="absolute top-0 right-0 w-32 h-32 bg-[#FFE169] opacity-5 blur-[80px] -mr-16 -mt-16" />
           <div className="flex items-center justify-between relative z-10 mb-2">
              <span className="text-[8px] font-black text-[var(--text-muted)] uppercase tracking-widest leading-none">{t.commitment}</span>
              <div className="p-1.5 bg-[#FFE16911] rounded-lg border border-[#FFE16933]">
                 <Award size={14} className="text-[#FFE169]" />
              </div>
           </div>
           <div className="flex items-center gap-4 relative z-10">
              <div className="flex gap-1.5 text-[#FFE169]">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className={cn(
                    "w-3.5 h-3.5 rounded-full flex items-center justify-center transition-all",
                    i <= Math.round(psych.avgCommitment) ? "bg-[#FFE169] shadow-[0_0_10px_#FFE16933]" : "bg-[var(--on-surface)]"
                  )}>
                    {i <= Math.round(psych.avgCommitment) && <Check size={7} className="text-black font-black" />}
                  </div>
                ))}
              </div>
              <span className="text-2xl font-black text-[var(--text-main)] italic font-mono leading-none">{psych.avgCommitment.toFixed(1)}/5.0</span>
           </div>
           <p className="text-[7px] text-[var(--text-muted)] font-black uppercase mt-3 tracking-widest relative z-10 opacity-60">Strategy adherence index</p>
        </div>
      </div>
    </div>
  );
};

const DownloadReportModal = ({ onCancel }: any) => {
  const [startDate, setStartDate] = useState(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onCancel}
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
      />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="relative w-full max-w-sm bg-[var(--background)] rounded-[32px] border border-[var(--border-color)] overflow-hidden shadow-2xl p-6"
      >
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 rounded-full bg-[#635BFF22] flex items-center justify-center text-[#635BFF]">
            <Download size={20} />
          </div>
          <h2 className="text-xl font-black text-[var(--text-main)] italic">Download Report</h2>
        </div>

        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-2 p-4 rounded-3xl border border-[var(--border-color)] bg-[var(--surface)] relative overflow-hidden">
            <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest px-1">Start Date</span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-black text-[var(--text-main)]">{new Date(startDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              <CalendarIcon size={18} className="text-[#635BFF]" />
            </div>
            <input 
              type="date" 
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
          </div>

          <div className="flex flex-col gap-2 p-4 rounded-3xl border border-[var(--border-color)] bg-[var(--surface)] relative overflow-hidden">
            <span className="text-[10px] font-bold text-[var(--text-muted)] uppercase tracking-widest px-1">End Date</span>
            <div className="flex items-center justify-between">
              <span className="text-sm font-black text-[var(--text-main)]">{new Date(endDate).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</span>
              <CalendarIcon size={18} className="text-[#635BFF]" />
            </div>
            <input 
              type="date" 
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
          </div>
        </div>

        <button 
          onClick={onCancel}
          className="w-full mt-8 bg-[#635BFF] py-5 rounded-2xl font-black text-sm flex items-center justify-center gap-3 shadow-xl shadow-[#635BFF44] text-white uppercase tracking-widest"
        >
          <Lock size={16} />
          Download
        </button>
      </motion.div>
    </div>
  );
};

const SettingsView = ({ settings, setSettings, t, resetData }: any) => {
  const [activeTab, setActiveTab ] = useState<'GENERAL' | 'POI' | 'SESSIONS' | 'ASSETS'>('GENERAL');
  const [newTag, setNewTag] = useState('');
  const [activeMarket, setActiveMarket] = useState<keyof AppSettings['assets']>('Forex');

  const addTag = () => {
    if (!newTag.trim()) return;
    const tag = newTag.trim();
    
    if (activeTab === 'POI') {
      setSettings({ ...settings, poiTypes: [...settings.poiTypes, tag] });
    } else if (activeTab === 'SESSIONS') {
      setSettings({ ...settings, sessions: [...settings.sessions, tag] });
    } else if (activeTab === 'ASSETS') {
      const currentAssets = (settings.assets as any)[activeMarket] || [];
      if (!currentAssets.includes(tag)) {
        setSettings({
          ...settings,
          assets: {
            ...settings.assets,
            [activeMarket]: [...currentAssets, tag]
          }
        });
      }
    }
    setNewTag('');
  };

  const removeTag = (tag: string) => {
    if (activeTab === 'POI') {
      setSettings({ ...settings, poiTypes: settings.poiTypes.filter((t: string) => t !== tag) });
    } else if (activeTab === 'SESSIONS') {
      setSettings({ ...settings, sessions: settings.sessions.filter((t: string) => t !== tag) });
    } else if (activeTab === 'ASSETS') {
      setSettings({
        ...settings,
        assets: {
          ...settings.assets,
          [activeMarket]: ((settings.assets as any)[activeMarket] || []).filter((t: string) => t !== tag)
        }
      });
    }
  };

  const SettingsRow = ({ icon: Icon, label, subLabel, onClick, color = "text-[var(--text-main)]", danger }: any) => (
    <button 
      onClick={onClick}
      className="flex items-center justify-between p-4 hover:bg-[var(--on-surface)] transition-colors group w-full text-left"
    >
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-10 h-10 rounded-xl flex items-center justify-center border border-[var(--border-color)] bg-[var(--background)]",
          danger ? "text-red-500 border-red-500/20" : color
        )}>
          <Icon size={20} />
        </div>
        <div className="flex flex-col items-start translate-y-[-1px]">
          <span className={cn("text-sm font-black", danger ? "text-red-500" : color)}>{label}</span>
          {subLabel && <span className="text-[10px] text-gray-500 font-bold opacity-80">{subLabel}</span>}
        </div>
      </div>
      <ChevronRight size={18} className="text-gray-500 group-hover:translate-x-1 transition-transform" />
    </button>
  );

  const SectionHeader = ({ label }: { label: string }) => (
    <span className="text-[11px] font-black text-[#635BFF] uppercase tracking-[0.2em] px-1 mb-2 block">{label}</span>
  );

  if (activeTab !== 'GENERAL') {
    return (
      <div className="flex flex-col gap-6 p-6">
        <button onClick={() => setActiveTab('GENERAL')} className="flex items-center gap-2 text-gray-500 font-bold text-xs uppercase tracking-widest mb-2">
          <ChevronLeft size={16} /> Back to Settings
        </button>
        
        <Card className="flex flex-col gap-6">
          <div className="flex items-center gap-3">
             <div className="bg-[#635BFF22] p-2 rounded-xl border border-[#635BFF33]">
                <SettingsIcon size={20} className="text-[#635BFF]" />
             </div>
             <span className="font-black text-lg italic uppercase">
                {activeTab === 'POI' ? t.entryReasons : activeTab === 'SESSIONS' ? t.sessionsTitle : 'Watchlist'}
             </span>
          </div>

          <div className="flex gap-1 p-1 bg-[var(--background)] rounded-xl border border-[var(--border-color)]">
             <button onClick={() => setActiveTab('POI')} className={cn("flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-colors", activeTab === 'POI' ? "bg-[#635BFF] text-white" : "text-gray-500")}>POI</button>
             <button onClick={() => setActiveTab('SESSIONS')} className={cn("flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-colors", activeTab === 'SESSIONS' ? "bg-[#635BFF] text-white" : "text-gray-500")}>SESSIONS</button>
             <button onClick={() => setActiveTab('ASSETS')} className={cn("flex-1 py-1.5 text-[10px] font-bold rounded-lg transition-colors", activeTab === 'ASSETS' ? "bg-[#635BFF] text-white" : "text-gray-500")}>ASSETS</button>
          </div>

          {activeTab === 'ASSETS' && (
            <div className="grid grid-cols-4 gap-1 p-1 bg-[var(--background)] rounded-xl border border-[var(--border-color)]">
              {(['Stock', 'Crypto', 'Forex', 'Commoditie'] as const).map((m) => (
                <button 
                  key={m}
                  onClick={() => setActiveMarket(m)}
                  className={cn(
                    "py-1 text-[8px] font-black rounded-lg transition-all",
                    activeMarket === m ? "bg-[#635BFF22] text-[#635BFF] border border-[#635BFF33]" : "text-gray-500"
                  )}
                >
                  {m}
                </button>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <input 
              type="text" 
              value={newTag} 
              onChange={(e) => setNewTag(e.target.value)}
              className="flex-1 bg-[var(--on-surface)] border border-[var(--border-color)] rounded-xl px-4 py-2 text-sm text-[var(--text-main)] outline-none focus:border-[#635BFF]"
              placeholder={activeTab === 'ASSETS' ? `Add ${activeMarket}...` : "..."}
            />
            <button 
              onClick={addTag}
              className="bg-[#635BFF] text-white p-2 rounded-xl"
            >
              <Plus size={24} />
            </button>
          </div>

          <div className="flex flex-wrap gap-2">
            {(activeTab === 'POI' 
              ? settings.poiTypes 
              : activeTab === 'SESSIONS' 
                ? settings.sessions 
                : ((settings.assets as any)[activeMarket] || [])
            ).map((tag: string) => (
              <TagItem key={tag} label={tag} onRemove={() => removeTag(tag)} />
            ))}
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8 p-6 pb-32">
      <div>
        <SectionHeader label="Appearance" />
        <div className="bg-[var(--surface)] border border-[var(--border-color)] rounded-[32px] overflow-hidden shadow-sm">
          <SettingsRow 
            icon={Monitor} 
            label="Theme" 
            subLabel={settings.theme === 'dark' ? "Dark Mode" : "Light Mode"} 
            onClick={() => setSettings({ ...settings, theme: settings.theme === 'dark' ? 'light' : 'dark' })} 
          />
        </div>
      </div>

      <div>
        <SectionHeader label="General" />
        <div className="bg-[var(--surface)] border border-[var(--border-color)] rounded-[32px] overflow-hidden shadow-sm">
          <div className="flex items-center justify-between p-4 border-b border-[var(--border-color)]">
             <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center border border-[var(--border-color)] bg-[var(--background)] text-[#635BFF]">
                   <DollarSign size={20} />
                </div>
                <div className="flex flex-col items-start translate-y-[-1px]">
                   <span className="text-sm font-black italic uppercase">Capital Amount</span>
                   <span className="text-[10px] text-[var(--text-muted)] font-bold opacity-80">Used for $ conversions</span>
                </div>
             </div>
             <input 
               type="number"
               value={settings.accountBalance || 0}
               onChange={(e) => setSettings({ ...settings, accountBalance: parseFloat(e.target.value) || 0 })}
               className="w-24 bg-[var(--background)] border border-[var(--border-color)] rounded-xl px-3 py-2 text-sm font-black text-[var(--text-main)] text-right outline-none focus:border-[#635BFF] font-mono"
             />
          </div>
          <SettingsRow 
            icon={SettingsIcon} 
            label="Journal Config" 
            subLabel="Manage POI, Sessions & Assets" 
            onClick={() => setActiveTab('POI')} 
          />
        </div>
      </div>

      <div>
        <SectionHeader label="Support" />
        <div className="bg-[var(--surface)] border border-[var(--border-color)] rounded-[32px] overflow-hidden shadow-sm">
          <SettingsRow 
            icon={Mail} 
            label="Contact Us" 
            subLabel="arkdevelopment@gmail.com" 
            onClick={() => {}} 
          />
        </div>
      </div>

      <div>
        <SectionHeader label="Legal" />
        <div className="bg-[var(--surface)] border border-[var(--border-color)] rounded-[32px] overflow-hidden shadow-sm">
          <div className="border-b border-[var(--border-color)]">
            <SettingsRow icon={ShieldCheck} label="Privacy Policy" onClick={() => {}} />
          </div>
          <div className="border-b border-[var(--border-color)]">
            <SettingsRow icon={Scale} label="Terms & Conditions" onClick={() => {}} />
          </div>
          <SettingsRow icon={RotateCcw} label="Refund Policy" onClick={() => {}} />
        </div>
      </div>

      <div>
        <SectionHeader label="Danger Zone" />
        <div className="bg-[var(--surface)] border border-red-500/20 rounded-[24px] overflow-hidden shadow-sm">
          <SettingsRow 
            icon={Trash2} 
            label="Delete Account" 
            subLabel="Permanently remove all your data" 
            danger 
            onClick={resetData} 
          />
        </div>
      </div>
    </div>
  );
};

const SearchableDropdown = ({ value, onChange, options, placeholder, icon: Icon }: any) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  
  const filteredOptions = options.filter((opt: string) => 
    opt.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="relative">
      <div 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-xl px-12 py-4 text-sm text-[var(--text-main)] outline-none focus:border-[#635BFF] cursor-pointer flex items-center justify-between"
      >
        <span>{value || placeholder}</span>
        <ChevronDown size={18} className={cn("transition-transform", isOpen && "rotate-180")} />
      </div>
      {Icon && <Icon size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />}
      
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 mt-2 bg-[var(--surface)] border border-[var(--border-color)] rounded-xl shadow-2xl z-[110] overflow-hidden flex flex-col max-h-60"
          >
            <div className="p-2 border-b border-[var(--border-color)]">
              <div className="relative">
                <input 
                  autoFocus
                  type="text"
                  value={search}
                  onFocus={(e) => e.target.select()}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search assets..."
                  className="w-full bg-[var(--on-surface)] border border-[var(--border-color)] rounded-lg px-8 py-2 text-xs outline-none focus:border-[#635BFF]"
                />
                <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
              </div>
            </div>
            <div className="overflow-y-auto scrollbar-hide py-1">
              {filteredOptions.length > 0 ? (
                filteredOptions.map((opt: string) => (
                  <button
                    key={opt}
                    onClick={() => {
                      onChange(opt);
                      setIsOpen(false);
                      setSearch('');
                    }}
                    className={cn(
                      "w-full px-4 py-3 text-left text-sm hover:bg-[#635BFF11] transition-colors",
                      value === opt ? "text-[#635BFF] font-black bg-[#635BFF11]" : "text-[var(--text-main)]"
                    )}
                  >
                    {opt}
                  </button>
                ))
              ) : (
                <div className="px-4 py-8 text-center text-xs text-gray-500">No assets found</div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const AddStrategyView = ({ onSave, onCancel, t }: any) => {
  const [name, setName] = useState('');
  const [rules, setRules] = useState(['Rule 1']);

  const addRule = () => {
    setRules([...rules, `Rule ${rules.length + 1}`]);
  };

  const removeRule = (index: number) => {
    setRules(rules.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    if (!name.trim()) return;
    const newStrategy: any = {
      id: crypto.randomUUID(),
      name,
      rules
    };
    onSave(newStrategy);
  };

  return (
    <motion.div 
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      className="fixed inset-0 bg-[var(--background)] z-[110] flex flex-col p-6 overflow-y-auto scrollbar-hide pb-32"
    >
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <IconButton icon={X} onClick={onCancel} />
          <h2 className="text-xl font-black text-[var(--text-main)] italic">Add Strategy</h2>
        </div>
      </div>

      <div className="flex flex-col gap-6">
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-gray-500 uppercase">Cover Image (optional)</label>
            <button className="flex items-center gap-1.5 text-[#FFD700] text-xs font-bold">
              <Lock size={14} /> Add Photo
            </button>
          </div>
          <div className="w-full aspect-[16/9] bg-[var(--surface)] border-2 border-dashed border-[var(--border-color)] rounded-3xl flex flex-col items-center justify-center gap-3 text-gray-500 cursor-pointer">
             <ImageIcon size={32} className="opacity-40" />
             <span className="text-sm font-bold opacity-60">Tap to upload image</span>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-gray-500 uppercase px-1">Name</label>
          <input 
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. Breakout"
            className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-xl px-4 py-4 text-sm text-[var(--text-main)] outline-none focus:border-[#635BFF]"
          />
        </div>

        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
             <label className="text-xs font-bold text-gray-500 uppercase px-1">Rules</label>
             <button onClick={addRule} className="text-[var(--text-main)]">
                <Plus size={20} />
             </button>
          </div>
          
          <div className="flex flex-col gap-3">
            {rules.map((rule, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <input 
                  type="text"
                  value={rule}
                  onChange={(e) => {
                    const newRules = [...rules];
                    newRules[idx] = e.target.value;
                    setRules(newRules);
                  }}
                  className="flex-1 bg-[var(--surface)] border border-[var(--border-color)] rounded-xl px-4 py-4 text-sm text-[var(--text-main)] outline-none focus:border-[#635BFF]"
                />
                <button onClick={() => removeRule(idx)} className="text-gray-500">
                  <MinusCircle size={20} />
                </button>
              </div>
            ))}
          </div>
        </div>

        <motion.button 
          whileTap={{ scale: 0.98 }}
          onClick={handleSave}
          className="mt-8 bg-[#635BFF] py-5 rounded-2xl font-black text-lg flex items-center justify-center gap-3 shadow-xl shadow-[#635BFF44] text-white"
        >
          Save Strategy
        </motion.button>
      </div>
    </motion.div>
  );
};

const StrategyListView = ({ strategies, onAdd, onCancel, t }: any) => {
  return (
    <motion.div 
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      className="fixed inset-0 bg-[var(--background)] z-[105] flex flex-col p-6 overflow-y-auto scrollbar-hide pb-32"
    >
      <div className="flex items-center gap-6 mb-8">
        <IconButton icon={ChevronLeft} onClick={onCancel} />
        <h2 className="text-xl font-black text-[var(--text-main)] italic">Strategy</h2>
      </div>

      {strategies.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center gap-4 py-20">
           <div className="bg-[#635BFF11] p-6 rounded-2xl border border-[#635BFF22]">
              <FolderKey size={48} className="text-[#635BFF]" />
           </div>
           <div className="flex flex-col gap-1">
             <h3 className="font-bold text-lg">No strategies yet</h3>
             <p className="text-xs text-gray-500 max-w-[200px]">Create your first strategy to reuse rules while journaling.</p>
           </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
           {strategies.map((s: any) => (
             <div key={s.id}>
               <Card className="flex flex-col gap-3">
                  <div className="flex items-center justify-between">
                     <h3 className="font-black text-lg">{s.name}</h3>
                     <span className="text-[10px] font-bold text-[#635BFF] bg-[#635BFF11] px-2 py-1 rounded-md">{s.rules.length} Rules</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                     {s.rules.slice(0, 4).map((r: string, i: number) => (
                       <span key={i} className="text-[10px] text-[var(--text-muted)] bg-[var(--on-surface)] px-2 py-0.5 rounded border border-[var(--border-color)]">{r}</span>
                     ))}
                     {s.rules.length > 4 && <span className="text-[10px] text-[var(--text-muted)]">+{s.rules.length - 4} more</span>}
                  </div>
               </Card>
             </div>
           ))}
        </div>
      )}

      <button 
        onClick={onAdd}
        className="fixed bottom-10 right-6 w-14 h-14 bg-[#635BFF] text-white rounded-2xl flex items-center justify-center shadow-2xl shadow-[#635BFF66] z-[106]"
      >
        <Plus size={28} />
      </button>
    </motion.div>
  );
};

const AddTradeScreen = ({ onSave, onCancel, settings, t }: any) => {
  const isAr = settings.language === 'AR';
  
  // Initialize date and time
  const now = new Date();
  const defaultDate = now.toISOString().split('T')[0];
  const defaultTime = now.toTimeString().split(' ')[0].slice(0, 5);

  const [formData, setFormData] = useState<Partial<Trade>>({
    pair: (settings.assets as any).Forex?.[0] || '',
    date: defaultDate,
    time: defaultTime,
    poi: settings.poiTypes[0],
    session: settings.sessions[0],
    bias: Bias.BULLISH,
    status: TradeStatus.WIN, // Default to Win for better initial UI
    pnlPercentage: 0,
    pnlCash: 0,
    notes: '',
    market: 'Forex',
    strategyId: settings.strategies?.[0]?.id || '',
    commitmentScore: 5
  });

  const [tradeOutcome, setTradeOutcome] = useState<'win' | 'loss'>('win');

  useEffect(() => {
    if (formData.status === TradeStatus.RUNNING) return;
    setFormData(prev => ({
      ...prev,
      status: tradeOutcome === 'win' ? TradeStatus.WIN : TradeStatus.LOSS
    }));
  }, [tradeOutcome]);

  const updateCurrentTime = () => {
    const d = new Date();
    setFormData(prev => ({
      ...prev,
      date: d.toISOString().split('T')[0],
      time: d.toTimeString().split(' ')[0].slice(0, 5)
    }));
  };

  const handlePercentageChange = (val: string) => {
    const percent = parseFloat(val) || 0;
    const cash = (percent / 100) * settings.accountBalance;
    setFormData(prev => ({
      ...prev,
      pnlPercentage: percent,
      pnlCash: Number(cash.toFixed(2))
    }));
  };

  const handleCashChange = (val: string) => {
    const cash = parseFloat(val) || 0;
    const percent = (cash / settings.accountBalance) * 100;
    setFormData(prev => ({
      ...prev,
      pnlCash: cash,
      pnlPercentage: Number(percent.toFixed(2))
    }));
  };

  const handleSubmit = () => {
    if (!formData.pair) return;

    let finalStatus = formData.status;
    const pnlPerc = formData.pnlPercentage || 0;
    const pnlCash = formData.pnlCash || 0;

    const newTrade: Trade = {
      ...formData as Trade,
      id: crypto.randomUUID(),
      status: finalStatus as TradeStatus,
      pnlPercentage: finalStatus === TradeStatus.LOSS ? -Math.abs(pnlPerc) : Math.abs(pnlPerc),
      pnlCash: finalStatus === TradeStatus.LOSS ? -Math.abs(pnlCash) : Math.abs(pnlCash),
      createdAt: Date.now()
    };
    DataService.saveTrade(newTrade);
    onSave();
  };

  return (
    <motion.div 
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      className="fixed inset-0 bg-[var(--background)] z-[100] flex flex-col overflow-y-auto scrollbar-hide pb-10"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-6 sticky top-0 bg-[var(--background)]/80 backdrop-blur-xl z-20 border-b border-[var(--border-color)]">
        <h2 className="text-xl font-black text-[var(--text-main)] italic uppercase tracking-tighter">
          {isAr ? 'تدوين صفقة' : 'Journal Entry'}
        </h2>
        <button onClick={onCancel} className="p-2 bg-[var(--on-surface)] rounded-2xl text-[var(--text-muted)] border border-[var(--border-color)] shadow-sm">
          <X size={20} />
        </button>
      </div>

      <div className="flex flex-col gap-6 p-6">
        {/* Status Toggle */}
        <div className="flex bg-[var(--on-surface)] p-1 rounded-2xl border border-[var(--border-color)] shadow-sm">
          <button 
            onClick={() => setFormData({...formData, status: TradeStatus.RUNNING})}
            className={cn(
              "flex-1 py-3 rounded-xl transition-all flex items-center justify-center gap-2 font-black text-[10px] uppercase",
              formData.status === TradeStatus.RUNNING ? "bg-[#635BFF] text-white shadow-lg" : "text-[var(--text-muted)]"
            )}
          >
            <Zap size={14} className={formData.status === TradeStatus.RUNNING ? "animate-pulse" : ""} />
            {isAr ? 'جارية' : 'Running'}
          </button>
          <button 
            onClick={() => setFormData({...formData, status: tradeOutcome === 'win' ? TradeStatus.WIN : TradeStatus.LOSS})}
            className={cn(
              "flex-1 py-3 rounded-xl transition-all flex items-center justify-center gap-2 font-black text-[10px] uppercase",
              formData.status !== TradeStatus.RUNNING ? "bg-[#635BFF] text-white shadow-lg" : "text-[var(--text-muted)]"
            )}
          >
             <CheckCircle2 size={14} />
             {isAr ? 'منتهية' : 'Closed'}
          </button>
        </div>

        {/* Pair Selection */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-black text-[#635BFF] uppercase tracking-widest ml-1">{isAr ? 'الزوج' : 'Pair'}</label>
          <SearchableDropdown 
            value={formData.pair}
            onChange={(val: string) => setFormData({ ...formData, pair: val })}
            options={(settings.assets as any)[formData.market || 'Forex'] || []}
            placeholder={isAr ? 'اختر الزوج...' : 'Select Pair...'}
            icon={Search}
          />
        </div>

        {/* Date & Time */}
        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-2">
            <label className="text-[10px] font-black text-[var(--text-muted)] uppercase tracking-widest ml-1">{isAr ? 'التاريخ' : 'Date'}</label>
            <div className="relative">
              <input 
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
                className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-xl px-4 py-3.5 text-sm font-bold text-[var(--text-main)] outline-none focus:border-[#635BFF] appearance-none"
              />
              <CalendarIcon size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between px-1">
              <label className="text-[10px] font-black text-[var(--text-muted)] uppercase tracking-widest">{isAr ? 'الوقت' : 'Time'}</label>
              <button onClick={updateCurrentTime} className="text-[9px] font-bold text-[#635BFF] underline underline-offset-2">Now</button>
            </div>
            <div className="relative">
              <input 
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({...formData, time: e.target.value})}
                className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-xl px-4 py-3.5 text-sm font-bold text-[var(--text-main)] outline-none focus:border-[#635BFF] appearance-none"
              />
              <Clock size={16} className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Market Capsules */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-black text-[var(--text-muted)] uppercase tracking-widest ml-1">{isAr ? 'السوق' : 'Market'}</label>
          <div className="flex flex-wrap gap-2">
            {['Forex', 'Crypto', 'Stock', 'Commoditie'].map((m) => (
              <button
                key={m}
                onClick={() => {
                  setFormData({ ...formData, market: m, pair: (settings.assets as any)[m]?.[0] || '' });
                }}
                className={cn(
                  "px-4 py-2 text-[9px] font-black rounded-lg transition-all uppercase border",
                  formData.market === m 
                    ? "bg-[#635BFF11] border-[#635BFF] text-[#635BFF]" 
                    : "bg-[var(--surface)] border-[var(--border-color)] text-[var(--text-muted)]"
                )}
              >
                {m === 'Forex' && (isAr ? 'فوركس' : 'Forex')}
                {m === 'Crypto' && (isAr ? 'كريبتو' : 'Crypto')}
                {m === 'Stock' && (isAr ? 'أسهم' : 'Stock')}
                {m === 'Commoditie' && (isAr ? 'سلع' : 'Commodities')}
              </button>
            ))}
          </div>
        </div>

        {/* Direction Toggle */}
        <div className="flex flex-col gap-2">
          <div className="flex bg-[var(--on-surface)] p-1 rounded-2xl border border-[var(--border-color)] shadow-sm h-14">
            <button 
              onClick={() => setFormData({...formData, bias: Bias.BULLISH})}
              className={cn(
                "flex-1 rounded-xl transition-all flex items-center justify-center gap-3 font-black text-xs uppercase",
                formData.bias === Bias.BULLISH ? "bg-[#00E676] text-[#003300] shadow-md" : "text-[var(--text-muted)] opacity-50"
              )}
            >
              <TrendingUp size={18} />
              {isAr ? 'شراء' : 'BUY'}
            </button>
            <button 
              onClick={() => setFormData({...formData, bias: Bias.BEARISH})}
              className={cn(
                "flex-1 rounded-xl transition-all flex items-center justify-center gap-3 font-black text-xs uppercase",
                formData.bias === Bias.BEARISH ? "bg-[#FF5252] text-white shadow-md" : "text-[var(--text-muted)] opacity-50"
              )}
            >
              <TrendingDown size={18} />
              {isAr ? 'بيع' : 'SELL'}
            </button>
          </div>
        </div>

        <div className="h-px bg-[var(--border-color)] my-1" />

        {/* Result Area */}
        {formData.status === TradeStatus.RUNNING ? (
          <div className="bg-[var(--surface)] rounded-3xl p-8 border border-[var(--border-color)] border-dashed flex flex-col items-center justify-center gap-4 animate-in fade-in zoom-in duration-500">
             <div className="w-16 h-16 rounded-full bg-[#635BFF11] flex items-center justify-center">
                <Zap size={32} className="text-[#635BFF] animate-pulse" />
             </div>
             <div className="flex flex-col items-center text-center">
                <span className="text-sm font-black italic uppercase text-[var(--text-main)]">{formData.pair} Running...</span>
                <p className="text-[10px] text-[var(--text-muted)] font-medium mt-1">Trade outcome is currently pending</p>
             </div>
          </div>
        ) : (
          <div className="flex flex-col gap-4 animate-in slide-in-from-bottom-4 fade-in duration-500">
            <div className="flex bg-[var(--on-surface)] p-1 rounded-xl border border-[var(--border-color)] w-fit mx-auto">
               <button 
                onClick={() => setTradeOutcome('win')}
                className={cn("px-6 py-2 rounded-lg text-[10px] font-black uppercase transition-all", tradeOutcome === 'win' ? "bg-[#00E676] text-[#003300] shadow-sm" : "text-[var(--text-muted)]")}
               >{isAr ? 'ربح' : 'WIN'}</button>
               <button 
                onClick={() => setTradeOutcome('loss')}
                className={cn("px-6 py-2 rounded-lg text-[10px] font-black uppercase transition-all", tradeOutcome === 'loss' ? "bg-[#FF5252] text-white shadow-sm" : "text-[var(--text-muted)]")}
               >{isAr ? 'خسارة' : 'LOSS'}</button>
            </div>

            <div className={cn(
              "grid grid-cols-2 gap-3 p-4 rounded-3xl border transition-all duration-500",
              tradeOutcome === 'win' ? "bg-[#00E67608] border-[#00E67633]" : "bg-[#FF525208] border-[#FF525233]"
            )}>
              <div className="flex flex-col gap-1.5">
                 <span className="text-[9px] font-black text-[var(--text-muted)] uppercase tracking-widest px-1">Amount ($)</span>
                 <div className="relative">
                   <input 
                    type="number"
                    value={formData.pnlCash || ''}
                    onChange={(e) => handleCashChange(e.target.value)}
                    placeholder="0.00"
                    className={cn(
                      "w-full bg-[var(--background)] border border-[var(--border-color)] rounded-2xl px-4 py-4 text-xl font-black text-right outline-none focus:border-[#635BFF] font-mono",
                      tradeOutcome === 'win' ? "text-[#00C853]" : "text-[#FF5252]"
                    )}
                   />
                   <DollarSign size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] opacity-40" />
                 </div>
              </div>
              <div className="flex flex-col gap-1.5">
                 <span className="text-[9px] font-black text-[var(--text-muted)] uppercase tracking-widest px-1">Percentage (%)</span>
                 <div className="relative">
                   <input 
                    type="number"
                    value={formData.pnlPercentage || ''}
                    onChange={(e) => handlePercentageChange(e.target.value)}
                    placeholder="0.0"
                    className={cn(
                      "w-full bg-[var(--background)] border border-[var(--border-color)] rounded-2xl px-4 py-4 text-xl font-black text-right outline-none focus:border-[#635BFF] font-mono",
                      tradeOutcome === 'win' ? "text-[#00C853]" : "text-[#FF5252]"
                    )}
                   />
                   <Percent size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] opacity-40" />
                 </div>
              </div>
            </div>
          </div>
        )}

        {/* Strategy Dropdown */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-black text-[#635BFF] uppercase tracking-widest ml-1">{isAr ? 'الإستراتيجية' : 'Strategy'}</label>
          <div className="relative">
            <select 
              value={formData.strategyId}
              onChange={(e) => setFormData({...formData, strategyId: e.target.value})}
              className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-xl px-12 py-4 text-sm font-bold text-[var(--text-main)] outline-none focus:border-[#635BFF] appearance-none cursor-pointer"
            >
              <option value="">Select Strategy</option>
              {settings.strategies.map((s: any) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            <FolderKey size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
            <ChevronDown size={18} className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
          </div>
        </div>

        {/* Sessions & POI (Small Capsules) */}
        <div className="grid grid-cols-2 gap-4">
           <div className="flex flex-col gap-2">
              <label className="text-[10px] font-black text-[var(--text-muted)] uppercase tracking-widest ml-1">{isAr ? 'الجلسة' : 'Session'}</label>
              <div className="flex flex-wrap gap-1.5">
                 {settings.sessions.map((s: string) => (
                    <button 
                      key={s}
                      onClick={() => setFormData({...formData, session: s})}
                      className={cn(
                        "px-3 py-1.5 text-[8px] font-bold rounded-lg border transition-all",
                        formData.session === s ? "bg-[#1A1A1A] text-white border-[#1A1A1A]" : "bg-[var(--surface)] text-[var(--text-muted)] border-[var(--border-color)]"
                      )}
                    >{s}</button>
                 ))}
              </div>
           </div>
           <div className="flex flex-col gap-2">
              <label className="text-[10px] font-black text-[var(--text-muted)] uppercase tracking-widest ml-1">{isAr ? 'نقطة الاهتمام' : 'POI'}</label>
              <div className="flex flex-wrap gap-1.5">
                 {settings.poiTypes.slice(0, 6).map((p: string) => (
                    <button 
                      key={p}
                      onClick={() => setFormData({...formData, poi: p})}
                      className={cn(
                        "px-3 py-1.5 text-[8px] font-bold rounded-lg border transition-all",
                        formData.poi === p ? "bg-[#1A1A1A] text-white border-[#1A1A1A]" : "bg-[var(--surface)] text-[var(--text-muted)] border-[var(--border-color)]"
                      )}
                    >{p}</button>
                 ))}
              </div>
           </div>
        </div>

        {/* Auto-expanding Notes */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] font-black text-[#635BFF] uppercase tracking-widest ml-1">{isAr ? 'ملاحظات سريعة' : 'Notes'}</label>
          <textarea 
            value={formData.notes}
            onChange={(e) => {
              setFormData({...formData, notes: e.target.value});
              e.target.style.height = 'auto';
              e.target.style.height = e.target.scrollHeight + 'px';
            }}
            placeholder={isAr ? 'ما الذي حدث اليوم؟' : 'What happened today?'}
            rows={2}
            className="w-full bg-[var(--surface)] border border-[var(--border-color)] rounded-2xl p-4 text-sm text-[var(--text-main)] outline-none focus:border-[#635BFF44] shadow-sm resize-none overflow-hidden transition-all"
          />
        </div>

        {/* Full width Save button */}
        <motion.button 
          whileTap={{ scale: 0.98 }}
          onClick={handleSubmit}
          className="w-full bg-[#635BFF] py-5 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl shadow-[#635BFF44] text-white mt-4 border border-white/10"
        >
          <Check size={20} />
          {isAr ? 'حفظ الصفقة' : 'Save Trade'}
        </motion.button>
      </div>
    </motion.div>
  );
};



// --- Main App ---

// --- Main App ---

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [authStateLoading, setAuthStateLoading] = useState(true);
  const [authStep, setAuthStep] = useState<'welcome' | 'signup' | 'login'>('welcome');

  const [activeTab, setActiveTab] = useState<'home' | 'calendar' | 'journal' | 'profile'>('home');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [showStrategies, setShowStrategies] = useState(false);
  const [showAddStrategy, setShowAddStrategy] = useState(false);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [calDate, setCalDate] = useState(new Date());
  const [displayMode, setDisplayMode] = useState<'percentage' | 'currency'>('percentage');
  const [notifications, setNotifications] = useState<{ id: string, message: string, type: 'win' | 'loss' }[]>([]);

  const addNotification = (message: string, type: 'win' | 'loss') => {
    const id = crypto.randomUUID();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setUser(user);
      if (user) {
        // Load user data from Firestore or LocalStorage as fallback
        const userPath = `users/${user.uid}`;
        try {
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          if (userDoc.exists()) {
            setSettings(userDoc.data() as AppSettings);
          } else {
            // Initialize user in Firestore if new
            const initialSettings = DataService.getSettings();
            await setDoc(doc(db, 'users', user.uid), initialSettings);
            setSettings(initialSettings);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, userPath);
        }
        setTrades(DataService.getTrades()); // Still using local trades for now, but in a real app we'd fetch from Firestore
      }
      setAuthStateLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const t = useMemo(() => settings.language === 'AR' ? TRANSLATIONS.AR : TRANSLATIONS.EN, [settings.language]);

  const refreshData = () => {
    setTrades(DataService.getTrades());
    setShowAddModal(false);
  };

  const handleSignOut = async () => {
    await signOut(auth);
    setAuthStep('welcome');
  };

  const resetData = () => {
    if (confirm('Are you sure? This will delete all trades and reset settings.')) {
      DataService.resetAll();
      setSettings(DEFAULT_SETTINGS);
      setTrades([]);
    }
  };

  useEffect(() => {
    if (user) {
      DataService.saveSettings(settings);
      // Sync settings to Firestore
      const userPath = `users/${user.uid}`;
      setDoc(doc(db, 'users', user.uid), settings).catch(error => {
        handleFirestoreError(error, OperationType.UPDATE, userPath);
      });
    }
  }, [settings, user]);

  // Handle active tab change to reset showSettings
  useEffect(() => {
    if (activeTab !== 'profile') {
      setShowSettings(false);
      setShowDownloadModal(false);
      setShowStrategies(false);
      setShowAddStrategy(false);
    }
  }, [activeTab]);

  // Smart Outcome Watcher
  useEffect(() => {
    const checkPrices = async () => {
      const runningTrades = trades.filter(t => t.status === TradeStatus.RUNNING && (t.slPrice || t.tpPrice));
      if (runningTrades.length === 0) return;

      const pairs = Array.from(new Set(runningTrades.map(t => t.pair)));
      
      for (const pair of pairs as string[]) {
        try {
          const base = pair.slice(0, 3);
          const quote = pair.slice(3);
          const response = await fetch(`https://api.exchangerate-api.com/v4/latest/${base}`);
          const data = await response.json();
          const currentPrice = data.rates[quote];
          
          if (!currentPrice) continue;

          for (const trade of runningTrades.filter(t => t.pair === pair)) {
            let hitStatus: TradeStatus | null = null;
            
            if (trade.bias === Bias.BULLISH) {
              if (trade.tpPrice && currentPrice >= trade.tpPrice) hitStatus = TradeStatus.WIN;
              else if (trade.slPrice && currentPrice <= trade.slPrice) hitStatus = TradeStatus.LOSS;
            } else {
              if (trade.tpPrice && currentPrice <= trade.tpPrice) hitStatus = TradeStatus.WIN;
              else if (trade.slPrice && currentPrice >= trade.slPrice) hitStatus = TradeStatus.LOSS;
            }

            if (hitStatus) {
              const updatedTrade = { 
                ...trade, 
                status: hitStatus,
                pnlPercentage: hitStatus === TradeStatus.WIN ? Math.abs(trade.pnlPercentage || 1) : -Math.abs(trade.pnlPercentage || 1)
              };
              DataService.updateTrade(updatedTrade);
              addNotification(`Trade ${trade.pair} hit ${hitStatus === TradeStatus.WIN ? 'Target (TP)' : 'Stop Loss (SL)'}!`, hitStatus === TradeStatus.WIN ? 'win' : 'loss');
            }
          }
          refreshData();
        } catch (error) {
          console.error("Monitor error:", error);
        }
      }
    };

    const interval = setInterval(checkPrices, 30000); // Check every 30s
    return () => clearInterval(interval);
  }, [trades]);

  const stats = useMemo(() => {
    const winners = trades.filter(t => t.status === TradeStatus.WIN);
    const losers = trades.filter(t => t.status === TradeStatus.LOSS);
    const profit = calculateMonthlyProfit(trades);
    const winRate = calculateWinRate(trades);
    return { winners, losers, profit, winRate };
  }, [trades]);

  const TabButton = ({ id, icon: Icon, label, active }: any) => (
    <button 
      onClick={() => setActiveTab(id)}
      className={cn(
        "flex flex-col items-center gap-1 transition-all duration-300 relative",
        active ? "text-[#635BFF]" : "text-[var(--text-muted)]"
      )}
    >
      <Icon size={24} className={cn("transition-transform duration-300", active && "scale-110")} />
      <span className="text-[10px] font-bold uppercase tracking-tighter">{label}</span>
      {active && (
        <motion.div 
          layoutId="activeTab"
          className="absolute -top-1 w-1 h-1 bg-[#635BFF] rounded-full"
        />
      )}
    </button>
  );

  const ProfileItem = ({ icon: Icon, label, subLabel, danger, onClick }: any) => (
    <button 
      onClick={onClick}
      className="flex items-center justify-between w-full p-4 border-b border-[var(--border-color)] last:border-none hover:bg-[var(--on-surface)] transition-colors group"
    >
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-10 h-10 rounded-xl flex items-center justify-center transition-colors",
          danger ? "bg-[#FF174411] text-[#FF1744]" : "bg-[var(--on-surface)] text-[var(--text-muted)] group-hover:bg-[#635BFF11] group-hover:text-[#635BFF]"
        )}>
          <Icon size={20} />
        </div>
        <div className="flex flex-col items-start leading-tight">
          <span className={cn("font-bold text-sm", danger ? "text-[#FF1744]" : "text-[var(--text-main)]")}>{label}</span>
          {subLabel && <span className="text-[10px] text-[var(--text-muted)]">{subLabel}</span>}
        </div>
      </div>
      {!danger && <ChevronLeft size={16} className={cn("text-[var(--text-muted)]", settings.language === 'EN' && "rotate-180")} />}
    </button>
  );

  const ProfileView = () => (
    <div className="flex flex-col gap-6 p-6 pb-32 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <AnimatePresence>
        {showDownloadModal && (
          <DownloadReportModal onCancel={() => setShowDownloadModal(false)} />
        )}
        {showStrategies && (
          <StrategyListView 
            strategies={settings.strategies || []} 
            onAdd={() => setShowAddStrategy(true)}
            onCancel={() => setShowStrategies(false)}
            t={t}
          />
        )}
        {showAddStrategy && (
          <AddStrategyView 
            onSave={(newStrategy: any) => {
              setSettings({
                ...settings,
                strategies: [...(settings.strategies || []), newStrategy]
              });
              setShowAddStrategy(false);
            }}
            onCancel={() => setShowAddStrategy(false)}
            t={t}
          />
        )}
      </AnimatePresence>
      <div className="flex flex-col items-center gap-4 mt-8">
        <div className="relative">
          <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-br from-[#635BFF] to-[#333FF3] shadow-2xl shadow-[#635BFF44]">
             <div className="w-full h-full rounded-full bg-[var(--surface)] p-1 border-4 border-[var(--background)] overflow-hidden">
                <img 
                  src={`https://api.dicebear.com/7.x/shapes/svg?seed=${settings.language}`} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
             </div>
          </div>
          <button className="absolute bottom-0 right-0 bg-[#635BFF] p-2 rounded-full border-4 border-[var(--background)] text-white shadow-lg">
             <Edit3 size={14} />
          </button>
        </div>
        <div className="flex flex-col items-center">
          <h2 className="text-2xl font-black text-[var(--text-main)] break-all px-4 text-center text-[var(--text-main)]">{user?.displayName || 'Trader'}</h2>
          <span className="text-xs text-[var(--text-muted)] font-medium tracking-tight">{user?.email}</span>
        </div>
      </div>

      <div className="flex flex-col gap-8 mt-4">
        {/* MANAGE SECTION */}
        <div className="flex flex-col gap-3">
          <span className="text-[10px] font-black text-[#635BFF] uppercase tracking-widest px-1">Manage</span>
          <div className="bg-[var(--surface)] border border-[var(--border-color)] rounded-2xl overflow-hidden shadow-sm">
            <ProfileItem icon={Lightbulb} label="Strategy" onClick={() => setShowStrategies(true)} />
            <ProfileItem icon={Download} label="Download Reports" onClick={() => setShowDownloadModal(true)} />
            <ProfileItem icon={SettingsIcon} label="Settings" onClick={() => setShowSettings(true)} />
            <ProfileItem icon={Award} label="Manage Subscription" subLabel="Unlock premium features" />
          </div>
        </div>

        {/* SUPPORT SECTION */}
        <div className="flex flex-col gap-3">
          <span className="text-[10px] font-black text-[#635BFF] uppercase tracking-widest px-1">Support</span>
          <div className="bg-[var(--surface)] border border-[var(--border-color)] rounded-2xl overflow-hidden shadow-sm">
            <ProfileItem icon={Lightbulb} label="Request New Feature" onClick={() => {}} />
            <ProfileItem icon={Share2} label="Share App" onClick={() => {}} />
            <ProfileItem icon={Bug} label="Bug Report" onClick={() => {}} />
          </div>
        </div>

        {/* ACCOUNT SECTION */}
        <div className="flex flex-col gap-3">
          <span className="text-[10px] font-black text-[#FF1744] uppercase tracking-widest px-1">Account</span>
          <div className="bg-[var(--surface)] border border-[var(--border-color)] rounded-2xl overflow-hidden shadow-sm">
            <ProfileItem icon={LogOut} label="Sign Out" danger onClick={handleSignOut} />
          </div>
        </div>
      </div>
    </div>
  );

  if (authStateLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-[var(--background)] text-[var(--text-main)]">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-10 h-10 border-4 border-[#635BFF] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  if (!user) {
    return (
      <AnimatePresence mode="wait">
        {authStep === 'welcome' && (
          <motion.div 
            key="welcome"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <WelcomeScreen 
              onCreateAccount={() => setAuthStep('signup')}
              onLogin={() => setAuthStep('login')}
            />
          </motion.div>
        )}
        {authStep === 'signup' && (
          <motion.div 
            key="signup"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <AuthScreen 
              mode="signup"
              onBack={() => setAuthStep('welcome')}
              onSuccess={() => {}}
              onToggleMode={() => setAuthStep('login')}
            />
          </motion.div>
        )}
        {authStep === 'login' && (
          <motion.div 
            key="login"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <AuthScreen 
              mode="login"
              onBack={() => setAuthStep('welcome')}
              onSuccess={() => {}}
              onToggleMode={() => setAuthStep('signup')}
            />
          </motion.div>
        )}
      </AnimatePresence>
    );
  }

  return (
    <div 
      className={cn(
        "max-w-xl mx-auto h-screen bg-[var(--background)] text-[var(--text-main)] relative overflow-x-hidden flex flex-col font-sans transition-colors duration-300",
        settings.theme === 'dark' ? 'dark' : '',
        settings.language === 'AR' ? 'rtl' : 'ltr'
      )}
      dir={settings.language === 'AR' ? 'rtl' : 'ltr'}
    >
      <AnimatePresence>
        {showAddModal && (
          <AddTradeScreen 
            onSave={refreshData} 
            onCancel={() => setShowAddModal(false)} 
            settings={settings}
            t={t}
          />
        )}
      </AnimatePresence>

      <main className="flex-1 overflow-y-auto scrollbar-hide">
        {activeTab === 'home' && (
          <div className="flex flex-col gap-6 px-1 pb-32 pt-12 w-full">
             <div className="flex items-center justify-between px-4">
                <div className="flex flex-col">
                   <h1 className="text-2xl font-black italic uppercase text-[var(--text-main)] leading-none">Performance</h1>
                   <span className="text-[10px] text-[var(--text-muted)] font-black uppercase tracking-[0.2em] mt-1">{settings.language === 'AR' ? 'تحليل الأرباح والخسائر' : 'P&L Analysis'}</span>
                </div>
                <div className="bg-[var(--surface)] p-1.5 rounded-lg border border-[var(--border-color)]" onClick={() => setActiveTab('profile')}>
                   <User size={18} className="text-[#635BFF]" />
                </div>
             </div>
 
             <AnalyticsView trades={trades} settings={settings} t={t} displayMode={displayMode} />
          </div>
        )}

        {activeTab === 'calendar' && (
          <div className="flex flex-col gap-6 px-0 pb-32 pt-12 w-full">
            <h1 className="text-2xl font-black italic uppercase text-center px-4 leading-none">Calendar</h1>
            <CalendarView 
              trades={trades} 
              t={t} 
              date={calDate} 
              setDate={setCalDate} 
              settings={settings} 
              displayMode={displayMode}
              setDisplayMode={setDisplayMode}
            />
          </div>
        )}

        {activeTab === 'journal' && (
          <div className="pt-16">
            <JournalView trades={trades} t={t} settings={settings} displayMode={displayMode} />
          </div>
        )}
        
        {activeTab === 'profile' && (
          showSettings 
            ? <div className="pt-8">
                <div className="px-6 mb-2">
                  <button onClick={() => setShowSettings(false)} className="flex items-center gap-2 text-[var(--text-muted)] font-bold text-xs uppercase tracking-widest">
                    <ChevronLeft size={16} /> Back
                  </button>
                </div>
                <SettingsView settings={settings} setSettings={setSettings} t={t} resetData={resetData} />
              </div>
            : <ProfileView />
        )}
      </main>

      {/* Center Floating Button */}
      <motion.button 
        whileTap={{ scale: 0.9 }}
        onClick={() => setShowAddModal(true)}
        className="fixed bottom-24 w-14 h-14 bg-[#635BFF] text-white rounded-2xl flex items-center justify-center shadow-xl shadow-[#635BFF44] z-50 left-1/2 -translate-x-1/2 border-4 border-[var(--background)]"
      >
        <Plus size={28} />
      </motion.button>

      {/* Bottom Nav Bar */}
      <nav className="fixed bottom-0 left-0 right-0 w-full bg-[var(--background)]/80 backdrop-blur-xl border-t border-[var(--border-color)] p-4 flex items-center justify-around z-50">
        <TabButton id="home" icon={BarChart2} label="Analytics" active={activeTab === 'home'} />
        <TabButton id="calendar" icon={CalendarIcon} label="Calendar" active={activeTab === 'calendar'} />
        <div className="w-10" /> {/* Spacer */}
        <TabButton id="journal" icon={BookOpen} label="History" active={activeTab === 'journal'} />
        <TabButton id="profile" icon={SettingsIcon} label="Settings" active={activeTab === 'profile'} />
      </nav>
      {/* Notifications */}
      <div className="fixed top-6 left-6 right-6 flex flex-col gap-3 z-[200] pointer-events-none">
        <AnimatePresence>
          {notifications.map(note => (
            <motion.div 
              key={note.id}
              initial={{ opacity: 0, y: -20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={cn(
                "w-full px-5 py-4 rounded-2xl flex items-center gap-4 border shadow-2xl pointer-events-auto",
                note.type === 'win' 
                  ? "bg-[#00C853] border-[#00C853] text-white" 
                  : "bg-[#FF1744] border-[#FF1744] text-white"
              )}
            >
              <div className="bg-white/20 p-2 rounded-xl">
                <Bell size={20} />
              </div>
              <div className="flex-1">
                <span className="text-[10px] font-black uppercase tracking-widest opacity-80 leading-none">Trade Update</span>
                <p className="text-sm font-black leading-tight">{note.message}</p>
              </div>
              <CheckCircle2 size={24} className="opacity-40" />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
