/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Trade, TradeStatus, AppSettings, DEFAULT_SETTINGS } from './types';

export const calculateWinRate = (trades: Trade[]): number => {
  const completedTrades = trades.filter(t => t.status !== TradeStatus.RUNNING);
  if (completedTrades.length === 0) return 0;
  
  const wins = completedTrades.filter(t => t.status === TradeStatus.WIN).length;
  return (wins / completedTrades.length) * 100;
};

export const calculateMonthlyProfit = (trades: Trade[]): number => {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  return trades
    .filter(t => {
      const d = new Date(t.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    })
    .reduce((sum, t) => sum + t.pnlPercentage, 0);
};

export const getDailyStats = (trades: Trade[]) => {
  const stats: Record<string, { pnl: number, wins: number, losses: number }> = {};
  
  trades.forEach(t => {
    if (!stats[t.date]) {
      stats[t.date] = { pnl: 0, wins: 0, losses: 0 };
    }
    stats[t.date].pnl += t.pnlPercentage;
    if (t.status === TradeStatus.WIN) stats[t.date].wins++;
    if (t.status === TradeStatus.LOSS) stats[t.date].losses++;
  });
  
  return stats;
};

export const getPerformanceByDayOfWeek = (trades: Trade[]) => {
  const days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const data = days.map((day, index) => {
    const dayTrades = trades.filter(t => new Date(t.date).getDay() === index);
    return {
      name: day,
      count: dayTrades.length,
      pnl: dayTrades.reduce((sum, t) => sum + t.pnlPercentage, 0)
    };
  });
  return data;
};

export const getPerformanceBySession = (trades: Trade[], sessions: string[]) => {
  return sessions.map(session => {
    const sessionTrades = trades.filter(t => t.session === session);
    return {
      name: session,
      count: sessionTrades.length,
      pnl: sessionTrades.reduce((sum, t) => sum + t.pnlPercentage, 0)
    };
  });
};

export const getPerformanceByPOI = (trades: Trade[], pois: string[]) => {
  return pois.map(poi => {
    const poiTrades = trades.filter(t => t.poi === poi);
    return {
      name: poi,
      count: poiTrades.length,
      pnl: poiTrades.reduce((sum, t) => sum + t.pnlPercentage, 0)
    };
  });
};

export const getAdvancedStats = (trades: Trade[]) => {
  const completedTrades = trades.filter(t => t.status !== TradeStatus.RUNNING);
  if (completedTrades.length === 0) {
    return {
      avgWin: 0,
      avgLoss: 0,
      rrRatio: 0,
      maxDrawdown: 0
    };
  }

  const wins = completedTrades.filter(t => t.status === TradeStatus.WIN);
  const losses = completedTrades.filter(t => t.status === TradeStatus.LOSS);

  const avgWin = wins.length > 0 ? wins.reduce((sum, t) => sum + Math.abs(t.pnlPercentage), 0) / wins.length : 0;
  const avgLoss = losses.length > 0 ? losses.reduce((sum, t) => sum + Math.abs(t.pnlPercentage), 0) / losses.length : 0;
  const rrRatio = avgLoss !== 0 ? avgWin / avgLoss : 0;

  // Max Drawdown calculation
  let maxPnl = 0;
  let currentPnl = 0;
  let maxDd = 0;

  const sortedTrades = [...completedTrades].sort((a, b) => a.createdAt - b.createdAt);
  
  sortedTrades.forEach(t => {
    currentPnl += t.pnlPercentage;
    if (currentPnl > maxPnl) {
      maxPnl = currentPnl;
    }
    const dd = maxPnl - currentPnl;
    if (dd > maxDd) {
      maxDd = dd;
    }
  });

  return {
    avgWin,
    avgLoss,
    rrRatio,
    maxDrawdown: maxDd
  };
};

export const getEquityCurve = (trades: Trade[]) => {
  const sortedTrades = trades
    .filter(t => t.status !== TradeStatus.RUNNING)
    .sort((a, b) => a.createdAt - b.createdAt);
    
  let cumulativePnL = 0;
  return sortedTrades.map(t => {
    cumulativePnL += t.pnlPercentage;
    return {
      date: new Date(t.createdAt).toLocaleDateString(),
      pnl: cumulativePnL,
      timestamp: t.createdAt
    };
  });
};

export const getConsistencyScore = (trades: Trade[]): number => {
  const completedTrades = trades.filter(t => t.status !== TradeStatus.RUNNING);
  if (completedTrades.length < 5) return 0;
  
  // A simple score based on win rate and profit factor
  const winRate = calculateWinRate(trades) / 100;
  const advanced = getAdvancedStats(trades);
  const profitFactor = advanced.avgLoss !== 0 ? (advanced.avgWin * winRate) / (advanced.avgLoss * (1 - winRate)) : 0;
  
  // Normalize to 0-100
  let score = (winRate * 40) + (Math.min(profitFactor, 3) / 3 * 60);
  return Math.min(Math.round(score), 100);
};

export const getWinLossBE = (trades: Trade[]) => {
  const completed = trades.filter(t => t.status !== TradeStatus.RUNNING);
  return {
    win: completed.filter(t => t.status === TradeStatus.WIN).length,
    loss: completed.filter(t => t.status === TradeStatus.LOSS).length,
    be: completed.filter(t => t.status === TradeStatus.BE).length,
    total: completed.length
  };
};

export const getMonthBestWorstDays = (trades: Trade[], date: Date) => {
  const stats = getDailyStats(trades);
  const month = date.getMonth();
  const year = date.getFullYear();
  
  let best = -Infinity;
  let worst = Infinity;
  let bestDate = '';
  let worstDate = '';
  
  Object.entries(stats).forEach(([dateStr, stat]) => {
    const d = new Date(dateStr);
    if (d.getMonth() === month && d.getFullYear() === year) {
      if (stat.pnl > best) {
        best = stat.pnl;
        bestDate = dateStr;
      }
      if (stat.pnl < worst) {
        worst = stat.pnl;
        worstDate = dateStr;
      }
    }
  });
  
  return {
    best: best === -Infinity ? 0 : best,
    bestDate,
    worst: worst === Infinity ? 0 : worst,
    worstDate
  };
};

export const getPsychStats = (trades: Trade[]) => {
  const moods: Record<string, { count: number, win: number, loss: number, pnl: number }> = {};
  let totalCommitment = 0;
  let commitmentCount = 0;

  trades.forEach(t => {
    if (t.status === TradeStatus.RUNNING) return;
    
    if (t.mood) {
      if (!moods[t.mood]) moods[t.mood] = { count: 0, win: 0, loss: 0, pnl: 0 };
      moods[t.mood].count++;
      moods[t.mood].pnl += t.pnlPercentage;
      if (t.status === TradeStatus.WIN) moods[t.mood].win++;
      if (t.status === TradeStatus.LOSS) moods[t.mood].loss++;
    }

    if (t.commitmentScore) {
      totalCommitment += t.commitmentScore;
      commitmentCount++;
    }
  });

  const moodsArray = Object.entries(moods).map(([name, stat]) => ({
    name,
    ...stat,
    winRate: stat.count > 0 ? (stat.win / stat.count) * 100 : 0
  })).sort((a, b) => b.count - a.count);

  return {
    moods: moodsArray,
    avgCommitment: commitmentCount > 0 ? totalCommitment / commitmentCount : 0
  };
};

// Simulation of Room DAO
const TRADES_KEY = 'pro_journal_trades_v2';
const SETTINGS_KEY = 'pro_journal_settings_v2';

export const DataService = {
  getTrades: (): Trade[] => {
    const data = localStorage.getItem(TRADES_KEY);
    return data ? JSON.parse(data) : [];
  },
  
  saveTrade: (trade: Trade) => {
    const trades = DataService.getTrades();
    trades.push(trade);
    localStorage.setItem(TRADES_KEY, JSON.stringify(trades));
  },

  updateTrade: (trade: Trade) => {
      const trades = DataService.getTrades().map(t => t.id === trade.id ? trade : t);
      localStorage.setItem(TRADES_KEY, JSON.stringify(trades));
  },
  
  deleteTrade: (id: string) => {
    const trades = DataService.getTrades().filter(t => t.id !== id);
    localStorage.setItem(TRADES_KEY, JSON.stringify(trades));
  },

  getSettings: (): AppSettings => {
    const data = localStorage.getItem(SETTINGS_KEY);
    if (!data) return DEFAULT_SETTINGS;
    try {
      const parsed = JSON.parse(data);
      return { ...DEFAULT_SETTINGS, ...parsed };
    } catch (e) {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings: (settings: AppSettings) => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  },

  resetAll: () => {
    localStorage.removeItem(TRADES_KEY);
    localStorage.removeItem(SETTINGS_KEY);
  }
};
